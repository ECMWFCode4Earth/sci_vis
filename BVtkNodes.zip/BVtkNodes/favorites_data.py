favorites = [('VTK2BlenderType', 'ToBlender'),
 ('VTKInfoNodeType', 'Info'),
 ('VTKConeSourceType', 'vtkConeSource'),
 ('VTKClipPolyDataType', 'vtkClipPolyData'),
 ('VTKColorMapperType', 'ColorMapper'),
 ('VTKColorMapType', 'ColorMap')]