options = [
    ("-o", "--output-folder", "output_folder"),
    ("-ts", "--time-start", "time_start"),
    ("-te", "--time-end", "time_end"),
    ("-cb", "--color-by", "color_by"),
    (None, "--range-min", "range_min"),
    (None, "--range-max", "range_max")
]


template = """        {sn}|{ln})
              if [ "$2" ]; then
                  {vn}=$2
                  shift
              else
                  die "Error: '{ln}' requires a non-empty option argument."
              fi
              ;;
        {sn}=?*|{ln}=?*)
            {vn}=${1#*=}
            ;;
        {sn}=|{ln}=)
            die "Error: '--output_folder' requires a non-empty option argument."
            ;;"""

template2 = """        {ln})
              if [ "$2" ]; then
                  {vn}=$2
                  shift
              else
                  die "Error: '{ln}' requires a non-empty option argument."
              fi
              ;;
        {ln}=?*)
            {vn}=${1#*=}
            ;;
        {ln}=)
            die "Error: '--output_folder' requires a non-empty option argument."
            ;;"""

for op in options:
    print(op[2]+'=""')

for op in options:
    if op[0]:
        t = template.replace("{sn}", op[0])
        t = t.replace("{ln}", op[1])
        t = t.replace("{vn}", op[2])
        print(t)
    else:
        t = template2.replace("{ln}", op[1])
        t = t.replace("{vn}", op[2])
        print(t)
