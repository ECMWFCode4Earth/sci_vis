#!/bin/bash

# Blender executable location
B=/home/simboden/Desktop/B279/blender

# Data location (in this case it's the current directory)
F=${PWD}

# -b : lancia blender in background
# -P : esegui questo script
# -- : passa il testo di seguito allo script python

# gli altri parametri sono hardcoded --- per un'altra soluzione vedi start2.sh
 
$B -b $F/visualize_mode_1.blend -P $F/render.py -- input:$F/monthly_sfc.nc output:$F/monthly_sfc.mp4 time_start:0 time_end:50



