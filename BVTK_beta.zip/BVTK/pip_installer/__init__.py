# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   pip_installer/__init__.py
#
#   Functions to automatically install pip packages on Blender's python.
# ---------------------------------------------------------------------------------


import socket
import importlib
import bpy
import subprocess
from urllib.request import urlopen
from .. utilities import *


def is_connected():
    remote_server = "216.58.192.142"

    try:
        urlopen("http://"+remote_server, timeout=1)
        return True
    except:
        pass

    try:
        host = socket.gethostbyname(remote_server)
        s = socket.create_connection((host, 80), 2)
        s.close()
        return True
    except:
        pass

    return False


def pip_update(draw_win=False):
    if not is_connected():
        return

    log.info("Updating pip.", draw_win=draw_win)

    try:
        get_pip = os.path.join(addon_path, "pip_installer/get-pip.py")
        log.info(subprocess.run([bpy.app.binary_path_python, get_pip], check=True,
                                stderr=subprocess.PIPE, stdout=subprocess.PIPE),
                 draw_win=draw_win)
        log.info("Pip updated.", draw_win=draw_win)
        return True
    except subprocess.CalledProcessError as e:
        message = (
            "Pip update failed.\n"
            "Output:      {}\n"
            "Stdout:      {}\n"
            "Stderr:      {}\n".format(e.output, e.stdout, e.stderr)
        )
        log.debug(message, draw_win=draw_win)
        log.warning("Pip update failed. Updating pip is usually necessary, the following\n"
                    "attempts to install the required libraries may fail.", draw_win=draw_win)
    return False


_connection_error = (
    "Unable to connect to the internet. Connection is required\n"
    "to install the {} package. Connect to the internet and try\n"
    "again."
)
_installation_success = "{} package successfully installed."


def pip_install(package, dependencies=(), check_conn=True, draw_win=True):
    """Try to install the specified package using pip.
    Return codes are:
    -1: Failure, no internet
     0: Failure, command failed
     1: Success
    """
    if check_conn and not is_connected():
        log.error(_connection_error.format(package), draw_win=draw_win)
        return -1

    pip_update()
    return __pip_install(package, dependencies, draw_win)


def __pip_install(package, dependencies=(), draw_win=True):
    try:
        importlib.import_module(package)
        return 1
    except:
        pass

    for dep in dependencies:
        if dep.__class__ in (().__class__, [].__class__)\
                and len(dep) == 2:
            __pip_install(dep[0], dep[1])
        else:
            __pip_install(dep)

    user_cmd = "python3 pip install {}".format(package)

    log.info("Installing {} via pip.".format(package), draw_win=draw_win)
    args = [bpy.app.binary_path_python, "-m", "pip", "install"]

    if len(dependencies):
        # If dependencies are specified they will be installed separately
        # This is needed to avoid creating duplicates of libraries already
        # installed inside Blender (for example numpy)
        args.append("--no-dependencies")

    args.append(package)

    try:
        log.debug(subprocess.run(args, check=True,
                  stderr=subprocess.PIPE, stdout=subprocess.PIPE), draw_win=draw_win)
    except subprocess.CalledProcessError as e:
        message = (
            "Command '{}' failed.\n"
            "Output:      {}\n"
            "Stdout:      {}\n"
            "Stderr:      {}\n".format(args, e.output, e.stdout, e.stderr)
        )
        log.debug(message, draw_win=draw_win)

    if is_loaded(package):
        log.info("{} package successfully installed.".format(package), draw_win=draw_win)
        return 1
    else:
        log.error("{} package failed to install. You can try to install it yourself by "
                  "running the command '{}'.".format(package, user_cmd), draw_win=draw_win)

    return 0


def dirs(path):
    path = os.path.abspath(path)
    folders = []

    while 1:
        path, folder = os.path.split(path)

        if folder != "":
            folders.append((folder, os.path.join(
                path, folder
            )))
        else:
            break

    folders.reverse()
    return folders


def up_to_dir(path, dir_name):
    dir_list = dirs(path)
    dir_path = None

    for folder in dir_list:
        if folder[0] == dir_name:
            dir_path = folder[1]

    return dir_path


def pip_update_package(package, check_conn=True, draw_win=True):
    """Update a local already installed package. It should work with blender
    native packages like numpy too. Return codes are:
    -3: Failure, couldn't locate the package
    -2: Failure, package wasn't already installed
    -1: Failure, no internet
     0: Failure, command failed
     1: Success
    """
    mod = is_loaded(package)

    if check_conn and not is_connected():
        log.error(_connection_error.format(package), draw_win=draw_win)
        return -1

    if not mod:
        log.error("{} package can't be update since it's not already installed."
                  .format(package), draw_win=draw_win)
        return -2

    if hasattr(mod, "__file__"):
        # Get module parent directory
        mod_path = os.path.abspath(
            os.path.join(os.path.dirname(mod.__file__), "..")
        )
    else:
        # Try to find the python site packages folder
        mod_path = up_to_dir(bpy.app.binary_path_python, "python")
        mod_path = os.path.join(mod_path, "lib/python3.5/site-packages")

    if not os.path.exists(mod_path):
        log.error("{} path does not exist.".format(mod_path), draw_win=draw_win)
        return -3

    args = [bpy.app.binary_path_python, "-m", "pip", "install",
            "--target={}".format(mod_path), "--upgrade", package]

    try:
        log.debug(subprocess.run(args, check=True,
                  stderr=subprocess.PIPE, stdout=subprocess.PIPE), draw_win=draw_win)
    except subprocess.CalledProcessError as e:
        message = (
            "Command '{}' failed.\n"
            "Output:      {}\n"
            "Stdout:      {}\n"
            "Stderr:      {}\n".format(args, e.output, e.stdout, e.stderr)
        )
        log.debug(message, draw_win=draw_win)
        return 0

    if is_loaded(package):
        log.info("{} package successfully updated.".format(package), draw_win=draw_win)
        return 1
    else:
        log.error("{} package failed to update.".format(package), draw_win=draw_win)
        return 0


def is_loaded(package):
    if package in globals():
        return globals()[package]
    try:
        import importlib
        return importlib.import_module(package)
    except:
        return False


# ---------------------------------------------------------------------------------
#   Install package operator
# ---------------------------------------------------------------------------------


class BVTK_OT_IstallPipPackage(bpy.types.Operator):
    """Install python pip package"""
    bl_idname = "bvtk.install_pip_package"
    bl_label = "Add socket"

    package = bpy.props.StringProperty()
    # Dependencies should be provided encoded as a JSON string
    # representing an array
    dependencies = bpy.props.StringProperty(default="[]")
    # Some packages may require to update other packages already
    # installed in order to work. This package should be
    # specified in an array encoded as a JSON string
    require_update = bpy.props.StringProperty(default="[]")
    node_path = bpy.props.StringProperty()

    def execute(self, context):
        deps = decode_JSON(self.dependencies)
        to_up = decode_JSON(self.require_update)

        if not is_connected():
            log.error(_connection_error.format(self.package))
            return {"CANCELLED"}

        if to_up:
            for package in to_up:
                if pip_update_package(package, check_conn=False, draw_win=False) != 1:
                    log.warning("Error while updating '{}' package.".format(package))

        if pip_install(self.package, deps, check_conn=False, draw_win=False) == 1:
            log.info(_installation_success.format(self.package), draw_win=True)
        elif to_up:
            log.info("Package has been installed, please\n"
                     "close and reopen Blender in order for\n" 
                     "changes to take effect", draw_win=True)
        else:
            log.error("Package {} failed to install.".format(self.package))

        if self.node_path:
            node = eval(self.node_path)
            if hasattr(node, "install_callback"):
                getattr(node, "install_callback")(self.package)

        return {"FINISHED"}


register.add_class(BVTK_OT_IstallPipPackage)
