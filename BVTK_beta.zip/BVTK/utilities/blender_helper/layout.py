# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   utilities/blender_helper/layout.py
#
#   Define functions to simplify the creation of blender layouts.
# ---------------------------------------------------------------------------------

from . b_data import *
from .. algo import addon_path, encode_JSON


def split_labels(layout, text, scale=1.0, initial_scale=0.0):
    """Add a label to the given layout for each
    newline in the given text.
    """
    tot_scale = initial_scale
    for text in text.split("\n"):
        layout.label(text=str(text))
        tot_scale += scale
    return tot_scale


def icon_box(layout, text, icon_code):
    """Create a box inside the given layout,
    with the given text and and the specified icon.
    """
    box = layout.box()
    box = side_spaced_layout(box)

    row = box.row()
    icon = row.column()
    icon.label(text="", icon=icon_code)
    col = row.column()
    col.separator()
    scale = 0.7
    col.scale_y = scale
    tot_scale = split_labels(col, text, scale, scale)
    icon.scale_y = tot_scale
    return box


def question_box(layout, text):
    """Create a box inside the given layout,
    with the given text and an error icon.
    """
    return icon_box(layout, text, "QUESTION")


def error_box(layout, text):
    """Create a box inside the given layout,
    with the given text and an error icon.
    """
    return icon_box(layout, text, "ERROR")


def try_update_box(node, layout, text):
    box = question_box(layout, text)
    box.operator("bvtk.node_update", text="Update").node_path = node_path(node)
    box.separator()


def install_package_box(layout, text, package, dependencies=None,
                        require_update=None, node=None):
    """Create a box inside the given layout,
    with the given text and an error icon.
    """
    from ... pip_installer import BVTK_OT_IstallPipPackage

    box = layout.box()
    box = side_spaced_layout(box)
    col = spaced_column(box)
    labels = col.column()
    labels.scale_y = 0.7
    split_labels(labels, text.format(package))
    col.separator()
    op = high_op(col, BVTK_OT_IstallPipPackage.bl_idname,
                 text="Install {}".format(package),
                 icon="LIBRARY_DATA_DIRECT")
    op.package = package

    if dependencies:
        op.dependencies = encode_JSON(dependencies)

    if require_update:
        op.require_update = encode_JSON(require_update)

    if node:
        op.node_path = node_path(node)

    return col


def header_box(layout, text):
    """Create a box inside the given layout,
    with the given text.
    """
    layout.box().label(text=str(text))


def error_icon(layout):
    """Create an error icon inside the given layout."""
    layout.label(text="", icon="ERROR")


def small_separator(layout):
    """Create an empty space in the given layout, smaller
    than the one made using the separator method.
    """
    col = layout.column()
    col.separator()
    col.scale_y = 0.8


def high_op(layout, *args, **kwargs):
    """Create a button for an operator in the given layout,
    a little taller than the default.
    """
    col = layout.column()
    col.scale_y = 1.3
    op = col.operator(*args, **kwargs)
    return op


def aside_label(layout, label, percentage=0.3):
    """Split the given layout and insert a label,
    then return the resulting split layout.
    """
    row = layout.split(percentage=percentage)
    row.label(text=str(label)+":")
    return row


def column_couple(layout, align=False, percentage=0.3):
    split = layout.split(percentage=percentage)
    col_1 = split.column(align=align)
    col_2 = split.column(align=align)
    return col_1, col_2


def label_prop(layout, label, prop, node, percentage=0.3):
    """Split the given layout and insert a label and
    a property, then return the resulting split layout.
    """
    row = aside_label(layout, label, percentage=percentage)
    row.prop(node, prop, text="")
    return row


def label_row(layout, label, percentage=0.3, align=True):
    """Split the given layout and insert a label and
    a property, then return the resulting split layout.
    """
    row = aside_label(layout, label, percentage=percentage)
    row = row.row(align=align)
    return row


def label_label(layout, label_a, label_b, percentage=0.3):
    """Split the given layout and insert a label and
    a property, then return the resulting split layout.
    """
    row = aside_label(layout, label_a, percentage=percentage)
    row.label(text=str(label_b))


def side_spaced_layout(layout):
    """Return a layout with additional space on the
    left and on the right.
    """
    row = layout.row()
    row.column()
    spaced_layout = row.column()
    row.column()
    return spaced_layout


def spaced_column(layout):
    """Return a column with additional space on the
    bottom and on the top.
    """
    col = layout.column()
    col.separator()
    layout.separator()
    return col


def get_aileron_font():
    if "Aileron-Regular" not in bpy.data.fonts:
        return bpy.data.fonts.load(os.path.join(addon_path, "Aileron-Regular.otf"))
    return bpy.data.fonts["Aileron-Regular"]


class BVTK_NodePanels:
    """Helper class to create subdivisions similar to panels
    inside node layouts. Child classes should redefine the
    protected class variable '_panels' and call the method
    'draw_panels' to draw the panels inside the given layout.
    """

    node_categories = bpy.props.BoolVectorProperty(size=32)
    _panels = []

    def draw_index_panel(self, context, layout, panel_index):
        """Draw the panel at the given index."""
        cat_name, cat_draw = self._panels[panel_index]
        is_open = self.node_categories[panel_index]

        box = layout.box()
        icon = "TRIA_DOWN" if is_open else "TRIA_RIGHT"
        op = box.operator(BVTK_OT_TogglePanel.bl_idname, icon=icon,
                          text=cat_name, emboss=False)
        op.index = panel_index
        op.encoded_path = encode_node_path(self)
        op.property_name = "node_categories"
        op.value = not is_open

        if is_open and cat_draw:
            c_box = side_spaced_layout(box)
            small_separator(box)
            cat_draw(self, context, c_box)

    def draw_panels(self, context, layout):
        """Draw all panels in the given layout."""
        for i, cat in enumerate(self._panels):
            self.draw_index_panel(context, layout, i)

    def draw_panel(self, context, layout, panel_name):
        """Draw the panel with the given name."""
        for i, cat in enumerate(self._panels):
            if cat[0] == panel_name:
                self.draw_index_panel(context, layout, i)


class BVTK_OT_TogglePanel(bpy.types.Operator):
    """Open/close panel"""
    bl_idname = "bvtk.toggle_panel"
    bl_label = "Run a VTK function in queue"
    encoded_path = bpy.props.StringProperty()
    property_name = bpy.props.StringProperty()
    index = bpy.props.IntProperty(default=-1)
    value = bpy.props.BoolProperty()

    def execute(self, context):
        node = decode_node_path(self.encoded_path)
        if not node:
            # log.error("Could not set property, invalid node path.")
            return {"CANCELLED"}

        prop = self.property_name
        if not hasattr(node, prop):
            # log.error("Could not set property, invalid node property.")
            return {"CANCELLED"}

        if self.index == -1:
            setattr(node, prop, self.value)
        else:
            getattr(node, prop)[self.index] = self.value

        return {'FINISHED'}
