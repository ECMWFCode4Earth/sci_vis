# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   utilities/blender_helper/geometry.py
#
#   Define functions to create and edit geometries.
# ---------------------------------------------------------------------------------


from . materials import *
from .. algo import is_subclass
import bmesh

# Default unwrap coordinates for plane
_plane_default_uv_co = ((0, 0), (1, 0), (1, 1), (0, 1))


def bmesh_plane(dim, pos=(0, 0, 0), uv_co=_plane_default_uv_co, uv_map=default_uv_map):
    """Create and return a bmesh plane with
    the given dimensions, in the given position.
    """
    bm = bmesh.new()
    verts = []  # same x, same y, same z

    for i_y in range(2):
        for i_x in range(2):
            i_x = i_x if i_y == 0 else 1 - i_x
            v = bm.verts.new((pos[0] + dim[0] * i_x,
                              pos[1] + dim[1] * i_y,
                              pos[2]))
            verts.append(v)

    f = [bm.faces.new(verts)]
    bmesh.ops.recalc_face_normals(bm, faces=f)

    if is_subclass(uv_co, {}):
        for uv_l, co in uv_co.items():
            if uv_l.lower() == "default":
                unwrap_plane_bm(bm)
            else:
                unwrap_plane_bm(bm, uv_co=co, uv_map=uv_l)
    else:
        unwrap_plane_bm(bm, uv_co, uv_map)

    return bm


def unwrap_plane_bm(plane_bmesh, uv_co=_plane_default_uv_co, uv_map=default_uv_map):
    uv_layer = get_item(plane_bmesh.loops.layers.uv, uv_map)
    plane_bmesh.faces.ensure_lookup_table()
    face = plane_bmesh.faces[0]

    if uv_co:
        for i in range(4):
            face.loops[i][uv_layer].uv = uv_co[i]


def mesh_plane(name, dim, pos=(0, 0, 0), uv_co=_plane_default_uv_co, uv_map=default_uv_map):
    me, ob = get_mesh(name)
    plane = bmesh_plane(dim, pos, uv_co, uv_map)
    plane.to_mesh(me)
    return me, ob
