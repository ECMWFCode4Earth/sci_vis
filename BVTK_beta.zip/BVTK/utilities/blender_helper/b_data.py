# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   utilities/blender_helper/b_data.py
#
#   Define functions to create and retrieve blender data.
# ---------------------------------------------------------------------------------


import bpy
import os
import json
from os.path import basename


def get_item(data, *args):
    """Get or create the item with key args[0] from data and return it."""
    item = data.get(args[0])
    if not item:
        item = data.new(*args)
    return item


def seek_item(data, *args):
    """Get or create the item with key args[0] from data and return it,
    together with a boolean flag to indicate if it already existed.
    """
    item = data.get(args[0])
    if not item:
        return data.new(*args), False
    return item, True


def set_link(data, item):
    """Link item to data if it's not already linked."""
    if item.name not in data:
        data.link(item)


def get_mesh(name):
    """Get or create an object and his mesh and return both."""
    me = get_item(bpy.data.meshes, name)
    ob = get_object(name, me)
    return me, ob


def get_curve(name, curve_type):
    """Get or create an object and his curve and return both."""
    curve = get_item(bpy.data.curves, name, curve_type)
    ob = get_object(name, curve)
    return curve, ob


def get_image(name, dim):
    """Get/Create an image and make sure it has the correct dimensions."""
    img, existed = seek_item(bpy.data.images, name, dim[0], dim[1])
    if existed:
        img.source = "GENERATED"
        img.generated_width = dim[0]
        img.generated_height = dim[1]
    return img


def load_image(filepath):
    """Get/Create an image and make sure it has the correct dimensions."""
    name = basename(filepath)

    if name in bpy.data.images:
        return bpy.data.images[name]

    return bpy.data.images.load(filepath)


def get_object(name, data):
    """Get or create object, set his data, add it to the current scene."""
    ob = get_item(bpy.data.objects, name, data)

    try:
        # Setting data to an object may rise an error if it's not
        # of the correct type, for example trying to set a mesh
        # as the data of a curve object.
        ob.data = data
    except TypeError:
        bpy.data.objects.remove(ob)
        return get_object(name, data)

    set_link(bpy.context.scene.objects, ob)
    return ob


def get_text(name, body, font_size=None):
    """Get/create a text data block"""
    text, ob = get_curve(name, "FONT")
    text.body = body

    if font_size:
        text.size = font_size

    return text, ob


# ---------------------------------------------------------------------------------
#   Nodes and node trees
# ---------------------------------------------------------------------------------


def behind_node(node, bl_idname):
    """Start from the given node and return the first node
    with the specified id name going back up the tree.
    """
    return behind_node_where(node, lambda n: n.bl_idname == bl_idname)


def behind_node_where(node, function, *args, **kwargs):
    """Start from the given node and return the first node
    with that satisfies the provided function,
    going back up the tree.
    """
    if function(node, *args, **kwargs):
        return node

    for input in node.inputs:
        for link in input.links:
            node = behind_node_where(link.from_node, function, *args, **kwargs)
            if node:
                return node


def copy_color_ramp(from_ramp, to_ramp):
    elements = to_ramp.elements
    new_elements = from_ramp.elements
    while len(elements) > len(new_elements):
        elements.remove(elements[0])
    for i, new_el in enumerate(new_elements):
        if i < len(elements):
            elements[i].color = new_el.color
            elements[i].position = new_el.position
        else:
            e = elements.new(new_el.position)
            e.color = new_el.color


# ---------------------------------------------------------------------------------
#   Useful variables
# ---------------------------------------------------------------------------------


def update_3d_view():
    """Force update of 3D View"""
    screen = bpy.context.screen
    if(screen):
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D':
                        # This updates viewport in Blender 2.79, not sure why
                        # space.viewport_shade = space.viewport_shade
                        continue


def escape_b_path(file_path):
    """Escape blender relative paths and return and absolute and real path."""
    return os.path.realpath(bpy.path.abspath(file_path))


def node_path(node):
    """Return node path of a node"""
    return 'bpy.data.node_groups['+repr(node.id_data.name)+'].nodes['+repr(node.name)+']'


def node_prop_path(node, propname):
    """Return node property path"""
    return node_path(node)+'.'+propname


def node_hash(node):
    """Return a short and identifying hash for the given node.
    Note that the hash is unreliable and may become invalid."""
    tree_i = -1
    tree = node.id_data
    for i, ng in enumerate(bpy.data.node_groups):
        if ng == tree:
            tree_i = i
    return "T{} {}".format(tree_i, node.name)


def encode_node_path(node):
    id_dict = {
        "tree_name": node.id_data.name,
        "node_name": node.name
    }
    return json.dumps(id_dict)


def decode_node_path(encoded_node):
    try:
        id_dict = json.loads(encoded_node)
        if "tree_name" not in id_dict:
            return None
        if "node_name" not in id_dict:
            return None
        tree_name = id_dict["tree_name"]
        node_name = id_dict["node_name"]

        if tree_name not in bpy.data.node_groups:
            return None
        tree = bpy.data.node_groups[tree_name]

        if node_name not in tree.nodes:
            return None
        node = tree.nodes[node_name]

        return node

    except (json.decoder.JSONDecodeError, TypeError):
        return None


def set_addon_pref(pref_name, value):
    pref = bpy.context.user_preferences.addons["BVTK"].preferences
    if hasattr(pref, pref_name):
        return setattr(pref, pref_name, value)


def get_addon_pref(pref_name):
    pref = bpy.context.user_preferences.addons["BVTK"].preferences
    if hasattr(pref, pref_name):
        return getattr(pref, pref_name)
    return None
