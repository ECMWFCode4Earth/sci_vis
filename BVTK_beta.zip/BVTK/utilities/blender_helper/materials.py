# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   utilities/blender_helper/materials.py
#
#   Define functions to create and edit materials and textures.
# ---------------------------------------------------------------------------------


from .. algo import index_abs
from . logger import *


# ---------------------------------------------------------------------------------
#   Naming conventions
# ---------------------------------------------------------------------------------
# User interface names, prefixes and suffixes
# Prefix for solid materials
solid_material_prefix = "BVTK Solid "
# Prefix for blend materials
blend_material_prefix = "BVTK Blend "
# Prefix for image materials
image_material_prefix = "BVTK Image "
# Prefix for volume materials
volume_material_prefix = "BVTK Volume "
# Default uv layer name for BVTK unwraps
default_uv_map = "BVTK UV"
# Prefix for the customized image texture nodes
image_node_name = "BVTK Image Node "
# Prefix for the customized color ramp nodes
ramp_node_name = "BVTK Color Ramp Node "


# ---------------------------------------------------------------------------------
#   Materials
# ---------------------------------------------------------------------------------


def blend_material(mesh, name, ramp, texture, reset=True):
    """Create a blend material and apply it to the given mesh."""
    name = blend_material_prefix + name
    mat, flag = material(mesh, name, reset)
    render_engine = bpy.context.scene.render.engine

    if render_engine == "CYCLES" or render_engine == "BLENDER_EEVEE":
        if not flag or not mat.use_nodes:
            setup_blend_tree(mat, ramp)
        else:
            nodes = mat.node_tree.nodes
            if not update_ramp_nodes(nodes, ramp):
                new_ramp_node(nodes, ramp)
    else:
        if not flag or mat.use_nodes:
            mat.use_nodes = False
            tex, ts = setup_texture(mat, texture, "BLEND")
            ts.texture_coords = "UV"
            ts.uv_layer = default_uv_map
        else:
            add_texture(mat, texture)

    return mat


def seek_image_material(mesh, name, img, reset=True):
    """Create an image material and apply it to the given mesh."""
    name = image_material_prefix + name
    mat, flag = material(mesh, name, reset)
    render_engine = bpy.context.scene.render.engine

    if render_engine == "CYCLES" or render_engine == "BLENDER_EEVEE":
        texture = None
        if not flag or not mat.use_nodes:
            flag = False
            setup_image_tree(mat, img)
        else:
            nodes = mat.node_tree.nodes
            if not update_image_nodes(nodes, img):
                new_image_node(nodes, img)
    else:
        texture = get_item(bpy.data.textures, name, "IMAGE")
        if not flag or mat.use_nodes:
            flag = False
            mat.use_nodes = False
            tex, ts = setup_texture(mat, texture, "IMAGE")
            ts.texture_coords = "UV"
            ts.uv_layer = default_uv_map
        else:
            add_texture(mat, texture)
        texture.image = img

    return mat, texture, flag


def image_material(mesh, name, img, reset=True):
    """Create an image material and apply it to the given mesh."""
    mat, texture, existed = seek_image_material(mesh, name, img, reset)
    return mat, texture


def add_image(mat, name, img, create_new=False, uv_layer=default_uv_map):
    """Add an image to an already existing image material"""
    render_engine = bpy.context.scene.render.engine
    name = image_material_prefix + name

    if render_engine == "CYCLES" or render_engine == "BLENDER_EEVEE":
        if create_new:
            setup_mix_shader(mat, img, uv_layer)
        else:
            update_mix_shader_img(mat, img)
    else:
        texture = get_item(bpy.data.textures, name, "IMAGE")
        texture.image = img
        ts = add_texture(mat, texture)
        ts.uv_layer = uv_layer
        set_last_texture(mat, texture, ts)


def voxel_material(mesh, name, file_path, texture=None, reset=True):
    """Create a voxel material and apply it to the given mesh.
    Works only with blender render engine."""
    name = volume_material_prefix + name
    mat, flag = material(mesh, name, reset, type="VOLUME")
    render_engine = bpy.context.scene.render.engine
    if render_engine == "CYCLES" or render_engine == "BLENDER_EEVEE":
        log.warning("Volumetric rendering is not supported in cycles, use blender render instead.")
        return None
    else:
        if not texture:
            texture = get_item(bpy.data.textures, name, "VOXEL_DATA")
        if not flag or texture.type != "VOXEL_DATA":
            texture, ts = setup_texture(mat, texture, "VOXEL_DATA")
            mat.volume.density = 0
            texture.voxel_data.file_format = "BLENDER_VOXEL"
            texture.voxel_data.filepath = file_path
            ts.texture_coords = "ORCO"
            ts.use_map_density = True
            ts.use_map_emission = True
            ts.use_map_color_emission = True
            mat.type = "VOLUME"
            mat.volume.density = 0
        else:
            add_texture(mat, texture)
            texture.voxel_data.filepath = file_path
    return mat


def solid_material(mesh, name, color=(0, 0, 0), reset=True):
    """Create a blend material and apply it to the given mesh."""
    name = solid_material_prefix + name
    mat, flag = material(mesh, name, reset)
    render_engine = bpy.context.scene.render.engine

    if render_engine == "CYCLES" or render_engine == "BLENDER_EEVEE":
        if not flag or not mat.use_nodes:
            setup_diffuse_tree(mat, color)
    else:
        if not flag or mat.use_nodes:
            mat.use_nodes = False
            mat.diffuse_color = color

    return mat


def material(mesh, name, reset_previous=True, **material_settings):
    """Get or create a material with the given name and
    return a tuple containing the material and a
    boolean set to true if the material already
    existed."""
    if reset_previous:
        # Remove all other materials from the mesh
        mesh.materials.clear()

    mat, existed = seek_item(bpy.data.materials, name)

    for key, value in material_settings.items():
        setattr(mat, key, value)

    apply_material(mesh, mat)

    return mat, existed


def apply_material(mesh, mat):
    if mat.name not in mesh.materials:
        mesh.materials.append(mat)


# ---------------------------------------------------------------------------------
#   Cycles
# ---------------------------------------------------------------------------------

# Node bl_idnames
diffuse_shader_id = "ShaderNodeBsdfDiffuse"
image_tex_id = "ShaderNodeTexImage"
mat_output_id = "ShaderNodeOutputMaterial"
uv_map_id = "ShaderNodeUVMap"
ramp_id = "ShaderNodeValToRGB"
gradient_id = "ShaderNodeTexGradient"
mix_shader_id = "ShaderNodeMixShader"


def ind_insert_between(node, node_a, node_b,
                       i_socket_a, i_socket_in,
                       i_socket_out, i_socket_b):
    """Insert node between node a and node b,
    taking linking the sockets based on the
    provided socket indexes.
     _____________      _____________      _____________
    | node_a      |    | node        |    | node_b      |
    |_____________|    |_____________|    |_____________|
    |             |    |             |    |             |
    |   i_socket_a|--->|i_socket_in  |    |             |
    |             |    | i_socket_out|--->|i_socket_b   |
    |_____________|    |_____________|    |_____________|

    """
    tree = node_a.id_data
    i_socket_a = index_abs(len(node_a.outputs), i_socket_a)
    i_socket_b = index_abs(len(node_b.inputs), i_socket_b)
    i_socket_in = index_abs(len(node.inputs), i_socket_in)
    i_socket_out = index_abs(len(node.outputs), i_socket_out)

    if None in (i_socket_a, i_socket_b, i_socket_in, i_socket_out):
        return None

    socket_a = node_a.outputs[i_socket_a]
    socket_in = node.inputs[i_socket_in]
    socket_out = node.outputs[i_socket_out]
    socket_b = node_b.inputs[i_socket_b]

    for link in tree.links:
        if link.from_socket == socket_a and link.to_socket == socket_b:
            tree.links.remove(link)

    tree.links.new(
        socket_a,
        socket_in
    )
    tree.links.new(
        socket_out,
        socket_b
    )


def socket_index(socket_list, socket):
    for i, soc in enumerate(socket_list):
        if soc.name == socket or soc == socket:
            return i

    return None


def insert_between(node, node_a, node_b,
                   k_socket_a, k_socket_in,
                   k_socket_out, k_socket_b):
    """Insert node between node a and node b,
    taking linking the sockets based on the
    provided socket names (keys).
     _____________      _____________      _____________
    | node_a      |    | node        |    | node_b      |
    |_____________|    |_____________|    |_____________|
    |             |    |             |    |             |
    |   k_socket_a|--->|k_socket_in  |    |             |
    |             |    | k_socket_out|--->|k_socket_b   |
    |_____________|    |_____________|    |_____________|

    """
    i_socket_a = socket_index(node_a.outputs, k_socket_a)
    i_socket_b = socket_index(node_b.inputs, k_socket_b)
    i_socket_in = socket_index(node.inputs, k_socket_in)
    i_socket_out = socket_index(node.outputs, k_socket_out)
    ind_insert_between(node, node_a, node_b, i_socket_a, i_socket_in,
                       i_socket_out, i_socket_b)


def insert_before(node, node_a, k_socket_in,
                  k_socket_out,  k_socket_a):
    """Insert the given node before node_a, taking care
    of the specified sockets.
             _____________      _____________
            | node        |    | node_a      |
            |_____________|    |_____________|
            |             |    |             |
            | k_socket_out|--->|k_socket_a   |
    ... --->|k_socket_in  |    |             |
            |_____________|    |_____________|

    """
    if k_socket_a not in node_a.inputs:
        return
    if k_socket_in not in node.inputs:
        return
    if k_socket_out not in node.outputs:
        return
    socket = node_a.inputs[k_socket_a]
    for link in socket.links:
        k_socket_x = link.from_socket.name
        insert_between(node, link.from_node, node_a,
                       k_socket_x, k_socket_in,
                       k_socket_out, k_socket_a)


def ind_insert_after(node, node_a, i_socket_a, i_socket_in,
                     i_socket_out):
    """Insert the given node after node_a, taking care
    of the specified sockets.
     _____________      _____________
    | node_a      |    | node        |
    |_____________|    |_____________|
    |             |    |             |
    |             |    | i_socket_out|---> ...
    |   i_socket_a|--->|i_socket_in  |
    |_____________|    |_____________|

    """
    i_socket_a = index_abs(len(node_a.outputs), i_socket_a)
    i_socket_in = index_abs(len(node.inputs), i_socket_in)
    i_socket_out = index_abs(len(node.outputs), i_socket_out)

    if None in (i_socket_a, i_socket_in, i_socket_out):
        return None

    socket = node_a.outputs[i_socket_a]
    for link in socket.links:
        i_socket_x = socket_index(link.to_node.inputs, link.to_socket)
        ind_insert_between(node, node_a, link.to_node,
                           i_socket_a, i_socket_in,
                           i_socket_out, i_socket_x)
        return True


def insert_after(node, node_a, k_socket_a, k_socket_in,
                 k_socket_out):
    """Insert the given node after node_a, taking care
    of the specified sockets.
     _____________      _____________
    | node_a      |    | node        |
    |_____________|    |_____________|
    |             |    |             |
    |             |    | k_socket_out|---> ...
    |   k_socket_a|--->|k_socket_in  |
    |_____________|    |_____________|

    """
    if k_socket_a not in node_a.outputs:
        return
    if k_socket_in not in node.inputs:
        return
    if k_socket_out not in node.outputs:
        return
    socket = node_a.outputs[k_socket_a]
    for link in socket.links:
        k_socket_x = link.to_socket.name
        insert_between(node, node_a, link.to_node,
                       k_socket_a, k_socket_in,
                       k_socket_out, k_socket_x)
        return True


def node_after(node, socket_out, node_a_idname=None):
    """Given a node, return the node after, following
    the specified socket (socket_out). In case there's
    more than one node linked, return the first. You
    can specify the node after should have.
     _____________      _____________
    | node        |    | node_a      |
    |_____________|    |_____________|
    |             |    |             |
    |   socket_out|--->|             |
    |_____________|    |_____________|

    """
    if socket_out not in node.outputs:
        return

    socket = node.outputs[socket_out]
    for link in socket.links:
        node = link.to_node
        if node_a_idname is None or node.bl_idname == node_a_idname:
            return node


def get_by_attribute(objects, attribute_name, attribute_value):
    for obj in objects:
        if obj.bl_idname:
            if getattr(obj, attribute_name) == attribute_value:
                return obj

    return objects.new(attribute_value)


def get_node_by_idname(nodes, idname):
    return get_by_attribute(nodes, "bl_idname", idname)


def link_nodes(node_a, output_name, node_b, input_name, links):
    from_socket = node_a.outputs[output_name]
    to_socket = node_b.inputs[input_name]
    links.new(to_socket, from_socket)


def setup_diffuse_tree(mat, color=None):
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    out_node = get_node_by_idname(nodes, mat_output_id)
    shader_node = get_node_by_idname(nodes, diffuse_shader_id)
    link_nodes(shader_node, "BSDF", out_node, "Surface", links)

    if color is not None:
        if len(color) == 3:
            color = color + (1,)
        shader_node.inputs["Color"].default_value = color


def setup_blend_tree(mat, ramp):
    setup_diffuse_tree(mat)

    # mat.use_nodes = True
    nodes = mat.node_tree.nodes
    out_node = get_node_by_idname(nodes, mat_output_id)
    uv_node = get_node_by_idname(nodes, uv_map_id)
    ramp_node = get_node_by_idname(nodes, ramp)
    customize_ramp_node(ramp_node)
    shader_node = get_node_by_idname(nodes, diffuse_shader_id)
    gradient_node = get_node_by_idname(nodes, gradient_id)
    links = mat.node_tree.links
    link_nodes(ramp_node, "Color", shader_node, "Color", links)
    link_nodes(gradient_node, "Fac", ramp_node, "Fac", links)
    # link_nodes(shader_node, "BSDF", out_node, "Surface", links)
    link_nodes(uv_node, "UV", gradient_node, "Vector", links)
    copy_color_ramp(ramp, ramp_node.color_ramp)
    uv_node.uv_map = default_uv_map


def setup_image_tree(mat, image):
    setup_diffuse_tree(mat)

    # mat.use_nodes = True
    nodes = mat.node_tree.nodes
    img_node = get_node_by_idname(nodes, image_tex_id)
    customize_image_node(img_node)
    shader_node = get_node_by_idname(nodes, diffuse_shader_id)
    out_node = get_node_by_idname(nodes, mat_output_id)
    uv_node = get_node_by_idname(nodes, uv_map_id)
    links = mat.node_tree.links
    link_nodes(img_node, "Color", shader_node, "Color", links)
    # link_nodes(shader_node, "BSDF", out_node, "Surface", links)
    link_nodes(uv_node, "UV", img_node, "Vector", links)
    img_node.image = image
    uv_node.uv_map = default_uv_map


def setup_mix_shader(mat, image, uv_map=default_uv_map):
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links

    o_img_node = get_image_node(nodes)
    o_shader_node = node_after(o_img_node, "Color", diffuse_shader_id)
    mix_node = get_node_by_idname(nodes, mix_shader_id)

    ind_insert_after(mix_node, o_shader_node, 0, 2, 0)

    uv_node, img_node, shader_node = img_base_nodes(mat, image)
    customize_image_node(img_node, 1)

    link_nodes(shader_node, "BSDF", mix_node, "Shader", links)
    link_nodes(o_img_node, "Alpha", mix_node, "Fac", links)

    uv_node.uv_map = uv_map


def img_base_nodes(mat, image):
    nodes = mat.node_tree.nodes
    links = mat.node_tree.links
    shader_node = nodes.new(diffuse_shader_id)
    img_node = nodes.new(image_tex_id)
    img_node.image = image
    uv_node = nodes.new(uv_map_id)

    link_nodes(uv_node, "UV", img_node, "Vector", links)
    link_nodes(img_node, "Color", shader_node, "Color", links)

    return uv_node, img_node, shader_node


def update_mix_shader_img(mat, image):
    update_image_nodes(mat.node_tree.nodes, image, 1)


def new_image_node(nodes, img):
    img_node = nodes.new(image_tex_id)
    img_node.image = img
    customize_image_node(img_node)


def new_ramp_node(nodes, ramp):
    ramp_node = nodes.new(ramp)
    copy_color_ramp(ramp, ramp_node.color_ramp)
    customize_ramp_node(ramp_node)


def format_custom_name(name, index):
    return name + str(index)


def customize_node(node, name, index):
    node.use_custom_color = True
    node.color = 0.3, 0.4, 0.5
    node.name = format_custom_name(name, index)
    node.label = format_custom_name(name, index)


def get_customized_nodes(nodes, name, index):
    c_nodes = []
    node_name = format_custom_name(name, index)
    for node in nodes:
        if node.name == node_name:
            c_nodes.append(node)
    return c_nodes


def get_image_nodes(nodes, index=0):
    return get_customized_nodes(nodes, image_node_name, index)


def get_image_node(nodes, index=0):
    img_nodes = get_image_nodes(nodes, index)
    if not img_nodes:
        return None
    return img_nodes[0]


def customize_image_node(node, index=0):
    customize_node(node, image_node_name, index)


def update_image_nodes(nodes, img, index=0):
    img_nodes = get_image_nodes(nodes, index)
    for node in img_nodes:
        node.image = img
    return img_nodes


def customize_ramp_node(node, index=0):
    customize_node(node, ramp_node_name, index)


def update_ramp_nodes(nodes, ramp, index=0):
    ramp_nodes = get_customized_nodes(nodes, ramp_node_name, index)
    for node in ramp_nodes:
        copy_color_ramp(ramp, node.color_ramp)
    return ramp_nodes


# ---------------------------------------------------------------------------------
#   Blender render
# ---------------------------------------------------------------------------------


def setup_texture(mat, texture, texture_type, **texture_settings):
    texture.type = texture_type
    texture = bpy.data.textures[texture.name]
    for key, value in texture_settings.items():
        setattr(texture, key, value)

    ts = set_active_texture(mat, texture)

    return texture, ts


def add_texture(mat, texture):
    if texture.name not in mat.texture_slots:
        ts = mat.texture_slots.add()
        ts.texture = texture
    else:
        ts = mat.texture_slots[texture.name]
    return ts


def set_last_texture(mat, texture, t_slot):
    last_ts = mat.texture_slots[0]
    last_tex = last_ts.texture
    last_ts.texture = texture
    t_slot.texture = last_tex

    last_uv = last_ts.uv_layer
    last_ts.uv_layer = t_slot.uv_layer
    t_slot.uv_layer = last_uv


def set_active_texture(mat, texture):
    for ts in mat.texture_slots:
        if ts:
            ts.use = False
    ts = add_texture(mat, texture)
    ts.use = True
    return ts


def set_active_material():
    pass
