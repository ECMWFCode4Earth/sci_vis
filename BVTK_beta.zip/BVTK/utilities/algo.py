# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   utilities/algo.py
#
#   Define useful algorithms.
# ---------------------------------------------------------------------------------


from inspect import isclass
from pathlib import Path
from math import gcd, log10, pow
import os
import json

addon_path = str(Path(os.path.realpath(__file__)).parent.parent)


def is_list_or_tuple(obj):
    return isinstance(obj, ().__class__) or isinstance(obj, [].__class__)


def push(array, element):
    array.insert(0, element)


def push_array(original, to_push):
    for el in reversed(to_push):
        if el in original:
            push(original, original.pop(original.index(el)))
            continue

        push(original, el)


def sort_by_keywords(array, keywords):
    array.sort(key=lambda dim: 0 if True in [
        str_contains(dim, k) for k in keywords
    ] else 1)


def str_contains(string, to_search):
    if is_list_or_tuple(to_search):
        return True in [str_contains(string, k) for k in to_search]

    return to_search.lower() in string.lower()


def get_class(object):
    """Get the given object class. Return the
    object if it is already a class.
    """
    if isclass(object):
        return object

    if hasattr(object, "__class__"):
        return object.__class__

    return None


def is_subclass(class_a, class_b):
    class_a = get_class(class_a)
    class_b = get_class(class_b)

    if class_a is None or class_b is None:
        return False

    return issubclass(class_a, class_b)


def float_scale(x):
    """Find and return the number of valid digits
    after the comma for the given float.
    """
    max_digits = 14
    int_part = int(abs(x))
    magnitude = 1 if int_part == 0 else int(log10(int_part)) + 1
    if magnitude >= max_digits:
        return 0
    frac_part = abs(x) - int_part
    multiplier = 10 ** (max_digits - magnitude)
    frac_digits = multiplier + int(multiplier * frac_part + 0.5)
    while frac_digits % 10 == 0:
        frac_digits /= 10
    return int(log10(frac_digits))


def float_gcd(a, b):
    """Find and return the float greatest common divisor."""
    sc = float_scale(a)
    sc_b = float_scale(b)
    sc = sc_b if sc_b > sc else sc
    fac = pow(10, sc)

    a = int(round(a*fac))
    b = int(round(b*fac))

    return round(gcd(a, b)/fac, sc)


def multi_gcd(a, b, *args):
    """Find the greatest common divisor of all the given numbers."""
    f_gcd = float_gcd(a, b)  # Final result
    for n in args:
        f_gcd = float_gcd(f_gcd, n)
    return f_gcd


def normalize_value(value, data_range):
    """Return the position of the value relative to the range,
    from 0 (range min) to 1 (range max).
    """
    min_r, max_r = data_range
    val = (value - min_r) / (max_r - min_r)
    val = min(1, max(0, val))
    return val


def normalize_tuple(tuple, data_range):
    for val in tuple:
        yield normalize_value(val, data_range)


def has_attributes(data, *attributes):
    """Return true if data has all of the specified arguments."""
    for att in attributes:
        if not hasattr(data, att):
            return False
    return True


def shift_reverse_range(n, shift_threshold=0, reverse=False):
    """Yield integers from 0 to n, eventually shifted and/or
    reversed. The indexes may be yielded in a shifted  order,
    based on the provided threshold. Here's a  visual example
    of a shift, with  size  equal to 10.

    Threshold = 0:      0  1  2  3  4  5  6  7  8  9
    Threshold = 5:      5  6  7  8  9  0  1  2  3  4
    """
    if shift_threshold < 0:
        shift_threshold = n+shift_threshold

    if not reverse:
        i = 0
        while i != n:

            if shift_threshold + i >= n:
                yield shift_threshold + i - n
            else:
                yield shift_threshold + i

            i += 1
    else:
        i = n-1
        while i >= 0:

            if shift_threshold + i >= n:
                yield shift_threshold + i - n
            else:
                yield shift_threshold + i

            i -= 1


def reverse_range(n, reverse=False):
    """Yield integers from 0 to n if the reverse
    bool is false, otherwise from n-1 to 0.
    """
    if not reverse:
        i = 0
        while i != n:
            yield i
            i += 1
    else:
        i = n-1
        while i >= 0:
            yield i
            i -= 1


def index_mirror(n, i, reverse=True):
    """Return a reversed index based on the specified
    size n, but only if the reverse variable is true.
    """
    if not reverse:
        return i
    return n - 1 - i


def index_abs(n, i):
    if i < 0:
        i = n+i

    if not -1 < i < n:
        # Index out of bounds
        return None

    return i


# ---------------------------------------------------------------------------------
#   JSON read from file / write to file
#   JSON object encode / decode
# ---------------------------------------------------------------------------------


def encode_JSON(obj, *args, **kwargs):
    try:
        return json.dumps(obj, *args, **kwargs)
    except TypeError:
        return ""


def decode_JSON(obj_str, *args, **kwargs):
    try:
        return json.loads(obj_str, *args, **kwargs)
    except (json.decoder.JSONDecodeError, TypeError):
        return None


def write_JSON(dictionary, file_path):
    """Write JSON dictionary to file."""
    file_path = os.path.realpath(file_path)
    text = encode_JSON(dictionary, indent=4, sort_keys=True)

    try:
        f = open(file_path, "w", encoding="utf-8")
    except FileNotFoundError:
        return False

    f.write(text)
    f.close()
    return True


def read_JSON(file_path):
    """Read JSON dictionary from file."""

    try:
        f = open(file_path, "r", encoding="utf-8")
    except FileNotFoundError:
        return None

    text = f.read()
    f.close()
    dic = decode_JSON(text)
    return dic


# ---------------------------------------------------------------------------------
#   Cache
# ---------------------------------------------------------------------------------
_cache = {}


def cache_store(obj_holder, obj_key, obj):
    class_dict = _cache.setdefault(obj_holder, {})
    class_dict[obj_key] = obj


def cache_retrieve(obj_holder, obj_key):
    if obj_holder in _cache:
        if obj_key in _cache[obj_holder]:
            return _cache[obj_holder][obj_key]

    return None


# ---------------------------------------------------------------------------------
#   Cpt file reader
# ---------------------------------------------------------------------------------


def read_cpt(file_path=None):
    # Adapted from James Boyle's script
    # https://scipy-cookbook.readthedocs.io/items/Matplotlib_Loading_a_colormap_dynamically.html
    import colorsys
    try:
        f = open(file_path)
    except:
        return None

    lines = f.readlines()
    f.close()

    rgb = []
    color_model = "RGB"
    last_color = None

    for l in lines:
        ls = l.split()
        if not ls:
            continue
        if l[0] == "#":
            if ls[-1] == "HSV":
                color_model = "HSV"
                continue
            else:
                continue
        if ls[0] == "B" or ls[0] == "F" or ls[0] == "N":
            pass
        else:

            color1 = (float(ls[1]),
                      float(ls[2]),
                      float(ls[3]))

            if color1 != last_color:
                rgb.append(color1)
                last_color = color1

            color2 = (float(ls[5]),
                      float(ls[6]),
                      float(ls[7]))

            if color2 != last_color:
                rgb.append(color2)
                last_color = color2

    if color_model == "HSV":
        for i in range(len(rgb)):
            color = rgb[i]
            rr, gg, bb = colorsys.hsv_to_rgb(color[0]/360, color[1], color[2])
            rgb[i] = (rr, gg, bb)

    elif color_model == "RGB":
        for i in range(len(rgb)):
            rgb[i] = rgb[i][0] / 255, rgb[i][1] / 255, rgb[i][2] / 255

    return rgb
