# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   utilities/netcdf_helper.py
#
#   Define useful functions and classes to manage netCDF4 package objects.
# ---------------------------------------------------------------------------------


from . algo import *
from .. import pip_installer


# NetCDF4 package is not required and may not
# be loaded. The following variable must always
# be checked before use.
netCDF4 = pip_installer.is_loaded("netCDF4")


def is_netcdf_dataset(obj):
    """Return true if the given object is a netCDF4 dataset."""
    if not netCDF4:
        return False

    if is_subclass(obj, netCDF4.Dataset):
        return True


def enum_dataset_variables(dataset, insert_before=()):
    items = []

    if hasattr(dataset, "variables"):
        # By default the keys method return an object
        # and not the simple list needed
        variables = [x for x in dataset.variables.keys()]

        push_array(variables, insert_before)

        for i, var_name in enumerate(variables):
            push(items, (var_name,
                         var_name,
                         var_name,
                         "WORLD_DATA",
                         i))

    return items


def coordinate_arrays(dataset, array, keywords=(), n_dim=None, splitter=" "):
    """Try to guess the possible coordinate arrays for
    the given axes. Return a list of array names."""
    coordinates = []

    for dim in array.dimensions:
        if str_contains(dim, keywords):
            if dim in dataset.variables:
                coordinates.append(dim)

    if not hasattr(array, "coordinates"):
        return coordinates

    s_c = array.coordinates.split(splitter)

    for i, coord in enumerate(s_c):
        if coord not in dataset.variables:
            continue

        elif n_dim is not None and len(dataset.variables[coord].dimensions) != n_dim:
            continue

        elif not str_contains(coord, keywords):
            continue

        coordinates.append(coord)

    return coordinates


def sorted_variables_n(dataset, keywords=(), n_dim=1):
    """Return a sorted list of variable names, based
    on the given keywords and variable dimensions."""
    vars = [var for var in dataset.variables]
    sort_by_keywords(vars, keywords)
    d_vars = []

    for var in vars:
        if len(dataset.variables[var].dimensions) == n_dim:
            d_vars.append(var)

    return d_vars


def time_arrays(dataset, keywords=("time", )):
    com_arrays = sorted_variables_n(dataset, keywords)

    if not com_arrays:
        return []

    return com_arrays


def time_array(dataset, keywords=("time", )):
    t_arr = time_arrays(dataset, keywords)

    if not t_arr:
        return None

    return dataset.variables[t_arr[0]]


def find_units_calendar(dataset):
    time_arr = time_array(dataset)
    units = None
    calendar = None

    if hasattr(time_arr, "units"):
        units = time_arr.units

    if hasattr(time_arr, "calendar"):
        calendar = time_arr.calendar

    return units, calendar
