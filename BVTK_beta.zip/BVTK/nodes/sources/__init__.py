# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   sources/__init__.py
#
#   Import and override default generated sources.
# ---------------------------------------------------------------------------------


from . gen_vtk_sources import *

_modules = [
    "gen_vtk_sources"
]
