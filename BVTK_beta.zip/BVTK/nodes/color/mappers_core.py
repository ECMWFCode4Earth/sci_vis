# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   converters/mappers_core.py
#
#   This file manages all the color mapper nodes and functions.
# ---------------------------------------------------------------------------------


from .. core import *


# ---------------------------------------------------------------------------------
#   Recognize color mappers
# ---------------------------------------------------------------------------------


def is_color_mapper(node):
    return issubclass(node.__class__, BVTK_ColorMapper)


# ---------------------------------------------------------------------------------
#   Base color mapper node class
# ---------------------------------------------------------------------------------


class BVTK_ColorMapper(BVTK_Node):
    # This class is useful at the moment just to recognize a color mapper
    # node. Every color mapper should be a child of this class.
    pass
