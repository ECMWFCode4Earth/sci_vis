# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   debug/__init__.py
#
#   Define nodes used for debugging.
# ---------------------------------------------------------------------------------


from .. core import *


class BVTK_NT_Info(Node, BVTK_NodePanels, BVTK_Node):
    """BVTK Info Node"""
    bl_idname = "BVTK_NT_Info"
    bl_label = "Info"

    def m_properties(self):
        return []

    def m_connections(self):
        return ["Input"], [], [], ["Output"]

    def update_cb(self):
        log.debug("Tree updated.")

    def setup(self):
        # Make info node wider to show all text
        self.width = 300

    def draw_buttons(self, context, layout):
        fs = "{:.5g}"  # Format string
        in_node, vtk_obj = self.get_input_node("Input")

        if not in_node:
            layout.label("Connect a node")

        elif not vtk_obj:
            layout.label("Input has not vtk object.")

        else:
            vtk_obj = resolve_algorithm_output(vtk_obj)
            if vtk_obj:
                layout.label(text="Type: " + vtk_obj.__class__.__name__)

                if hasattr(vtk_obj, "GetNumberOfPoints"):
                    layout.label(text="Points: " + str(vtk_obj.GetNumberOfPoints()))
                if hasattr(vtk_obj, "GetNumberOfCells"):
                    layout.label(text="Cells: " + str(vtk_obj.GetNumberOfCells()))
                if hasattr(vtk_obj, "GetBounds"):
                    layout.label(text="X range: " + fs.format(vtk_obj.GetBounds()[0]) +
                                 " - " + fs.format(vtk_obj.GetBounds()[1]))
                    layout.label(text="Y range: " + fs.format(vtk_obj.GetBounds()[2]) +
                                 " - " + fs.format(vtk_obj.GetBounds()[3]))
                    layout.label(text="Z range: " + fs.format(vtk_obj.GetBounds()[4]) +
                                 " - " + fs.format(vtk_obj.GetBounds()[5]))
                data = {}
                if hasattr(vtk_obj, "GetPointData"):
                    data["Point data "] = vtk_obj.GetPointData()
                if hasattr(vtk_obj, "GetCellData"):
                    data["Cell data "] = vtk_obj.GetCellData()
                if hasattr(vtk_obj, "GetFieldData"):
                    data["Field data "] = vtk_obj.GetFieldData()
                for k in data:
                    d = data[k]
                    for i in range(d.GetNumberOfArrays()):
                        arr = d.GetArray(i)
                        r = arr.GetRange()
                        arr_name = arr.GetName()
                        row = layout.row()
                        row.label(text="{}: '{}': {} - {}".format(k, arr_name,
                                                                  fs.format(r[0]),
                                                                  fs.format(r[1])))

        layout.separator()
        # self.draw_panels(context, layout)
        high_op(layout, "bvtk.node_update", text="update").node_path = node_path(self)

    def draw_time(self, context, layout):
        fs = "{:.5g}"  # Format string
        g_range = self.cache_retrieve("global_range")

        if g_range:
            for k in g_range:
                for arr_name, ran in g_range[k].items():
                    layout.label(text="{}: '{}': {} - {}".format(k, arr_name,
                                                                 fs.format(ran[0]),
                                                                 fs.format(ran[1])))

    # _panels = [
    #     ("Time", draw_time),
    # ]

    def apply_properties(self, vtkobj):
        in_node, out_port = self.get_input_node("Input")

        if not in_node or not out_port:
            return

        g_range = {}
        data = {}
        vtk_obj = resolve_algorithm_output(out_port)

        if hasattr(vtk_obj, "GetPointData"):
            data["Point data"] = vtk.vtkDataSet.POINT

        if hasattr(vtk_obj, "GetCellData"):
            data["Cell data"] = vtk.vtkDataSet.CELL

        if hasattr(vtk_obj, "GetFieldData"):
            data["Field data"] = vtk.vtkDataSet.FIELD

        for k in data:
            d = vtk_obj.GetAttributesAsFieldData(data[k])
            arrays = g_range.setdefault(k, {})

            if not d:
                continue

            for i in range(d.GetNumberOfArrays()):
                arr = d.GetArray(i)
                name = arr.GetName()
                arrays[name] = complete_time_range(out_port, data[k], i)

        self.cache_store("global_range", g_range)

    def apply_inputs(self, vtkobj):
        pass

    def get_output(self, socket):
        return self.get_input_node("Input")[1]


cat = "Debug"
register.set_category_icon(cat, "VIEWZOOM")
add_node(BVTK_NT_Info, cat)
