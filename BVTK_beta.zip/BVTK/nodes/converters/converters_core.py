# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   converters/converters_core.py
#
#   This file manages all the converters nodes and functions and should be
#   imported by all converters.
# ---------------------------------------------------------------------------------


from .. color.mappers_core import is_color_mapper
from .. core import *


# ---------------------------------------------------------------------------------
#   Output types keys
# ---------------------------------------------------------------------------------


output_mesh = "MESH"
output_volume = "VOLUME"
output_image = "IMAGE"
output_text = "TEXT"


# ---------------------------------------------------------------------------------
#   Recognize converters
# ---------------------------------------------------------------------------------


def is_converter(node):
    return issubclass(node.__class__, BVTK_Converter)


# ---------------------------------------------------------------------------------
#   Base converter node class
# ---------------------------------------------------------------------------------


class BVTK_Converter(BVTK_Node):

    def start_scan(self, context):
        if self.auto_update:
            bpy.ops.bvtk.auto_update_scan(
                node_name=self.name,
                tree_name=context.space_data.node_tree.name)

    auto_update = bpy.props.BoolProperty(default=False, update=start_scan, name="Auto update")
    output_name = bpy.props.StringProperty(name="Name", default="Mesh")
    output_type = None  # To be defined in subclasses

    def m_connections(self):
        return ["Input"], [], [], []

    def m_properties(self):
        return []

    def draw_buttons(self, context, layout):
        self.label_prop(layout, "Output name", "output_name")
        self.label_prop(layout, "Auto update", "auto_update")
        self.label_prop(layout, "Output as", "output_type")
        disable_update = True

        if hasattr(self, "draw_options"):
            # Subclasses should define the draw options method
            # to add additional content to the layout
            disable_update = bool(self.draw_options(context, layout))

        small_separator(layout)
        row = layout.row()
        row.enabled = not disable_update
        high_op(row, "bvtk.node_update", text="Update").node_path = node_path(self)

    def get_color_mapper(self):
        return behind_node_where(self, is_color_mapper)

    def update_cb(self):
        input_node, input_obj = self.get_input_node("Input")
        color_node = self.get_color_mapper()

        if color_node:
            color_node.update()  # setting auto range

        if hasattr(self, "convert"):
            self.convert(input_obj, color_node)


# ---------------------------------------------------------------------------------


converters_cat = "Converters"
register.set_category_icon(converters_cat, "APPEND_BLEND")
