# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   netcdf_tools/converter.py
#
#   Define custom nodes to convert netCDF4 dataset to blender objects.
# ---------------------------------------------------------------------------------


import numpy
from ... utilities.netcdf_helper import *
from .. converters.converters_core import *
from .. instruments import BVTK_NT_TimeSelector
from ... import pip_installer


# ----------------------------------------------------------------
#   NetCDF4 Converter
# ----------------------------------------------------------------


def install_netCDF4_callback(package):
    global netCDF4
    netCDF4 = pip_installer.is_loaded(package)


def install_netCDF4_box(layout, node):
    install_package_box(layout, "The netCDF4 package by Unidata\n"
                        "is required in order to use\n"
                        "this reader.", "netCDF4",
                        ["numpy",
                         "cython",
                         "setuptools",
                         ("cftime", ("cython", "numpy"))
                         ], ["numpy"],
                        node
                        )


class BVTK_NT_NetCDF4Converter(Node, BVTK_NodePanels, BVTK_Converter):
    """ """
    bl_idname = "BVTK_NT_NetCDF4Converter"
    bl_label = "NetCDF4 Converter"

    _output_types = [
        # (output_volume, "Volume", "Generate a volume as output. Works only in blender render.", "MOD_CAST", 0),
        (output_image, "Image", "Generate image as output.", "IMAGE_DATA", 1)
    ]

    def coordinate_arrays(self, keywords=()):
        in_obj = self.get_input_obj("Input")
        array = self.get_var_array()
        coords = ()

        if array:
            coords = coordinate_arrays(in_obj, array, keywords)

        return enum_dataset_variables(in_obj, coords)

    def sort_dimensions(self, *keywords):
        """Sort the array dimensions based on the given keywords.
        Return an enum items list.
        """
        array = self.get_var_array()

        if not array:
            return None

        dims = [d for d in array.dimensions]
        sort_by_keywords(dims, keywords)
        return [(d, d, d) for d in dims]

    def x_dimension_arrays(self, context):
        return self.sort_dimensions("west", "east", "lon")

    def y_dimension_arrays(self, context):
        return self.sort_dimensions("south", "north", "lat")

    def z_dimension_arrays(self, context):
        return self.sort_dimensions("lev")

    def t_dimension_arrays(self, context):
        items = self.sort_dimensions("time")
        items.append(("None", "None", "None"))
        return items

    def latitude_arrays(self, context):
        return self.coordinate_arrays("lat")

    def longitude_arrays(self, context):
        return self.coordinate_arrays("lon")

    def z_level_arrays(self, context):
        return self.coordinate_arrays("lev")

    # Coordinate arrays
    latitude_array = bpy.props.EnumProperty(items=latitude_arrays)
    longitude_array = bpy.props.EnumProperty(items=longitude_arrays)
    z_level_array = bpy.props.EnumProperty(items=z_level_arrays)

    # Dimensions
    x_dimension = bpy.props.EnumProperty(items=x_dimension_arrays, name="X dimension")
    y_dimension = bpy.props.EnumProperty(items=y_dimension_arrays, name="Y dimension")
    z_dimension = bpy.props.EnumProperty(items=z_dimension_arrays, name="Z dimension")
    t_dimension = bpy.props.EnumProperty(items=t_dimension_arrays, name="Time dimension")

    # Output options
    output_type = bpy.props.EnumProperty(items=_output_types)
    x_shift = bpy.props.FloatProperty(default=0, name="Shift x", subtype="PERCENTAGE", min=-100, max=100, soft_min=0)
    y_shift = bpy.props.FloatProperty(default=0, name="Shift y", subtype="PERCENTAGE", min=-100, max=100, soft_min=0)

    # Background image options
    background = bpy.props.PointerProperty(type=bpy.types.Image)
    # Background upper left point coordinates
    background_ul_north = bpy.props.FloatProperty(name="N", min=-90, max=90, default=90)
    background_ul_east = bpy.props.FloatProperty(name="E", min=-180, max=180, default=-180)
    # Background bottom right point coordinates
    background_br_north = bpy.props.FloatProperty(name="N", min=-90, max=90, default=-90)
    background_br_east = bpy.props.FloatProperty(name="E", min=-180, max=180, default=180)

    def m_properties(self):
        return [
            "x_shift",          "y_shift",          "output_type",
            "x_dimension",      "y_dimension",      "z_dimension",
            "t_dimension",      "latitude_array",
            "longitude_array",  "z_level_array",
        ]

    def install_callback(self, package):
        install_netCDF4_callback(package)

    def get_var_array(self):
        color_mapper = self.get_color_mapper()

        if color_mapper:
            return color_mapper.get_color_array()

        return None

    def draw_coordinates(self, context, layout):
        array = self.get_var_array()

        self.label_prop(layout, "X dimension", "x_dimension")
        self.label_prop(layout, "Y dimension", "y_dimension")
        self.label_prop(layout, "Time dimension", "t_dimension")

        small_separator(layout)
        if array and hasattr(array, "coordinates"):
            label_label(layout, "Coordinates", array.coordinates)

        self.label_prop(layout, "Longitude", "longitude_array")
        self.label_prop(layout, "Latitude", "latitude_array")

    def draw_options(self, context, layout):
        if not netCDF4:
            install_netCDF4_box(layout, self)
            return True

        in_node, in_obj = self.get_input_node("Input")

        if not in_node:
            question_box(layout, "Connect a node")
            return

        if not in_obj:
            question_box(layout, "Input in null, try \nto update.")
            return

        if not issubclass(in_obj.__class__, netCDF4.Dataset):
            error_box(layout, "Input must be a netCDF4 dataset.\n"
                              "Please use a netCDF4 easy reader.")
            return True

        small_separator(layout)
        self.draw_panels(context, layout)
        small_separator(layout)
        col_1, col_2 = column_couple(layout, True)
        col_1.label("X shift:")
        col_1.label("Y shift:")
        col_2.prop(self,  "x_shift", text="")
        col_2.prop(self,  "y_shift", text="")

    def draw_background_options(self, context, layout):
        row = aside_label(layout, "Background")
        row.template_ID(self, "background", open="image.open")
        row = label_row(layout, "Upper left")
        row.prop(self, "background_ul_north")
        row.prop(self, "background_ul_east")
        row = label_row(layout, "Bottom right")
        row.prop(self, "background_br_north")
        row.prop(self, "background_br_east")

    _panels = [
        ("Coordinates and dimensions", draw_coordinates),
        ("Background options", draw_background_options)
    ]

    def convert(self, input_obj, color_node):
        if not netCDF4:
            return

        time_sel = behind_node(self, BVTK_NT_TimeSelector.bl_idname)

        if input_obj and is_subclass(netCDF4.Dataset, input_obj):

            BVTK_NetCDFImageConverter(
                input_obj,
                self,
                color_node,
                time_sel
            )

    def apply_properties(self, vtk_obj):
        pass

    def apply_inputs(self, vtkobj):
        pass

    def get_output(self, socket):
        return self.cache_retrieve(self._netCDF_key)


# ----------------------------------------------------------------
#   NetCDF4 Converter
# ----------------------------------------------------------------


def matrix_slice(arr, axis, index, index_end=None):
    if not index_end:
        index_end = index + 1
    sl = [slice(None)] * arr.ndim
    sl[axis] = slice(index, index_end)
    return arr[tuple(sl)]


def matrix_slice_all(array, dont_slice=(), index=0):

    for ax in range(array.ndim):

        if ax not in dont_slice:
            array = matrix_slice(array, ax, index)

    return array


def decreasing(array):
    v_a = array[0]
    v_b = array[-1]

    return v_b < v_a


def dim_index(dim_name, dim):

    for i, n in enumerate(dim):
        if n == dim_name:
            return i

    return None


def first_last(array, shift=0, divide=1):
    v_0 = (array[0] + shift) / divide
    v_1 = (array[-1] + shift) / divide
    return v_0, v_1


class BVTK_NetCDFImageConverter:

    def __init__(self, data,
                 converter=None,
                 color_mapper=None,
                 time_sel=None,
                 create_plane=True):

        self.texture = None
        self.output_name = converter.output_name
        self.time_step = 0
        self.create_plane = create_plane
        self.dataset = data
        self.data_array = None
        self.d_range = None
        self.dim = None
        self.x_i = None
        self.y_i = None
        self.t_i = None
        self.x_array = None
        self.y_array = None
        self.z_array = None
        self.x_shift = converter.x_shift / 100
        self.y_shift = converter.y_shift / 100
        self.coord_uv = None
        self.img_shape = None

        if color_mapper:
            self.texture = color_mapper.get_texture()
            self.d_range = color_mapper.range_min, color_mapper.range_max

            if color_mapper.color_by not in data.variables:
                log.error("{}: variable not found.".format(color_mapper.color_by))
                return

        if time_sel:
            self.time_step = time_sel.time_step - 1

        if not self.setup_coordinates(converter):
            return

        self.setup_coord_uv(
            (converter.background_ul_east, converter.background_ul_north),
            (converter.background_br_east, converter.background_br_north)
        )
        self.data_array = data.variables[color_mapper.color_by]
        self.dim = [d for d in self.data_array.dimensions]
        self.data_array = self.data_array[:]
        self.x_i = self.dim_index(converter.x_dimension)
        self.y_i = self.dim_index(converter.y_dimension)
        self.z_i = self.dim_index(converter.z_dimension)
        self.t_i = self.dim_index(converter.t_dimension)

        self.img_shape = self.data_array.shape[self.x_i], self.data_array.shape[self.y_i]
        self.shift_on_x(self.x_shift)
        self.shift_on_y(self.y_shift)

        if self.t_i is not None:
            self.single_slice(self.t_i, self.time_step)

        if decreasing(self.x_array):
            self.flip_x()

        if decreasing(self.y_array):
            self.flip_y()

        if converter.output_type == output_image:
            self.to_image(converter.background)

        elif converter.output_type == output_volume:
            self.to_volume()

    def to_image(self, background_img=None):
        self.multi_slice((self.x_i, self.y_i))
        self.normalize()
        log.debug("Image writing start.")
        img = get_image(self.output_name, self.img_shape)
        color_ramp = self.texture.color_ramp
        self.data_array = numpy.array([color_ramp.evaluate(x) for x in self.data_array.flat])
        img.pixels = self.data_array.flatten().tolist()
        log.debug("Image writing done.")
        # Create mesh and material
        me, ob = mesh_plane(self.output_name, self.img_shape, uv_co={
            "default": (),
            "BVTK Blue Marble UV": self.coord_uv.reshape(4, 2).tolist()

        })
        mat, tex, ex = seek_image_material(me, self.output_name, img)

        if not background_img:
            i_path = os.path.join(addon_path, "media/blue_marble/blue_marble_01.jpg")
            log.info("Loading {}".format(i_path))
            background_img = load_image(i_path)

        add_image(mat, "Blue Marble", background_img, not ex, "BVTK Blue Marble UV")

    def to_volume(self):
        pass

    def setup_coord_uv(self, upper_left, bottom_right):
        xs = 180    # Maximum longitude
        ys = 90     # Maximum latitude

        uv_x_min, uv_x_max = first_last((upper_left[0], bottom_right[0]), xs, 1)
        uv_y_min, uv_y_max = first_last((bottom_right[1], upper_left[1]), ys, 1)

        delta_x = uv_x_max - uv_x_min
        delta_y = uv_y_max - uv_y_min

        x_min, x_max = first_last(self.x_array, xs, delta_x)
        y_min, y_max = first_last(self.y_array, ys, delta_y)

        self.coord_uv = numpy.array(
            [[[x_min, y_min], [x_max, y_min]],
             [[x_max, y_max], [x_min, y_max]]]
        )

        # self.coord_uv = numpy.array(
        #     [[[uv_x_min, uv_y_min], [uv_x_max, uv_y_min]],
        #      [[uv_x_max, uv_y_max], [uv_x_min, uv_y_max]]]
        # )

    def setup_coordinates(self, converter):
        """Define X, Y, Z coordinate arrays."""

        if converter.longitude_array not in self.dataset.variables:
            log.error("{}: longitude array not found.".format(converter.longitude_array))
            return False

        if converter.latitude_array not in self.dataset.variables:
            log.error("{}: latitude array not found.".format(converter.latitude_array))
            return False

        self.x_array = self.flat_coordinate(
            self.dataset.variables[converter.longitude_array],
            converter.x_dimension
        )
        self.y_array = self.flat_coordinate(
            self.dataset.variables[converter.latitude_array],
            converter.y_dimension
        )

        if converter.z_level_array in self.dataset.variables:
            self.z_array = self.flat_coordinate(
                self.dataset.variables[converter.z_level_array],
                converter.z_dimension
            )

        return True

    def normalize(self, none_val=0):
        delta = abs(self.d_range[1] - self.d_range[0])
        self.data_array -= self.d_range[0]
        self.data_array /= delta
        self.data_array = numpy.clip(self.data_array, 0, 1)
        self.data_array = numpy.where(self.data_array is None, none_val, self.data_array)

    def flip_uv(self, *axis):
        for ax in axis:
            self.coord_uv = numpy.flip(self.coord_uv, ax)

    def shift_uv(self, percentage, ax):
        shift = (numpy.amax(self.coord_uv[:, :, ax]) - numpy.amin(self.coord_uv[:, :, ax])) * percentage
        self.coord_uv[:, :, ax] -= shift

    def shift(self, percentage, array_ax, img_ax):
        self.shift_uv(percentage, img_ax)
        self.data_array = numpy.roll(
            self.data_array, int(self.img_shape[img_ax] * percentage), axis=array_ax
        )

    def shift_on_x(self, percentage):
        self.shift(percentage, self.x_i, 0)

    def shift_on_y(self, percentage):
        self.shift(percentage, self.y_i, 1)

    def flip(self, ax, uv_axis):
        self.data_array = numpy.flip(self.data_array, ax)
        self.flip_uv(uv_axis)

    def flip_x(self):
        self.flip(self.x_i, 1)

    def flip_y(self):
        self.flip(self.y_i, (0, 1))

    def flat_coordinate(self, array, axis_name):
        ax_i = dim_index(axis_name, array.dimensions)
        return matrix_slice_all(array[:], (ax_i,)).squeeze()

    def dim_index(self, dim_name):
        return dim_index(dim_name, self.dim)

    def single_slice(self, ax, index=0):
        self.data_array = matrix_slice(self.data_array, ax, index)

    def multi_slice(self, keep=()):
        self.data_array = matrix_slice_all(self.data_array, keep)


# ----------------------------------------------------------------


cat = "NetCDF Tools"
register.set_category_icon(cat, "WORLD")
add_node(BVTK_NT_NetCDF4Converter, cat)
add_node(BVTK_NT_NetCDF4Converter, converters_cat)
