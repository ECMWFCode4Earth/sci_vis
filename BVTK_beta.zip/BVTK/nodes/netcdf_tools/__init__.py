# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   netcdf_tools/__init__.py
#
#   Define custom nodes to easily import netCDF files.
# ---------------------------------------------------------------------------------


from . netcdf_converter import *

_modules = [
    "netcdf_converter"
]

# ----------------------------------------------------------------
#   NetCDF4 Reader
# ----------------------------------------------------------------


class BVTK_NT_NetCDF4EasyReader(Node, BVTK_Node):
    """ """
    bl_idname = "BVTK_NT_NetCDF4EasyReader"
    bl_label = "NetCDF4 Easy Reader"

    file_name = bpy.props.StringProperty(subtype="FILE_PATH", name="FileName")
    _netCDF_key = "netCDF_array"

    def m_properties(self):
        return []

    def m_connections(self):
        return [], [], [], ["Output"]

    def install_callback(self, package):
        install_netCDF4_callback(package)

    def draw_buttons(self, context, layout):
        if not netCDF4:
            install_netCDF4_box(layout, self)
            return

        layout.prop(self, "file_name")

    def apply_properties(self, vtk_obj):
        file_name = escape_b_path(self.file_name)

        if file_name:
            try:
                root_grp = netCDF4.Dataset(file_name, "a")
                self.cache_store(self._netCDF_key, root_grp)
            except FileNotFoundError:
                log.warning("'{}' file not found.".format(file_name))
            except OSError:
                log.warning("'{}' invalid file.".format(file_name))
            except Exception as e:
                log.warning(e)

    def apply_inputs(self, vtkobj):
        pass

    def get_output(self, socket):
        return self.cache_retrieve(self._netCDF_key)


# ----------------------------------------------------------------


add_node(BVTK_NT_NetCDF4EasyReader, cat)
