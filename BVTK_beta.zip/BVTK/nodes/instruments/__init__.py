# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   instruments/__init__.py
#
#   Define custom nodes to solve specific problems, for example
#   managing time.
# ---------------------------------------------------------------------------------


from .. core import *
from ... utilities.netcdf_helper import *
from ... import pip_installer


# ----------------------------------------------------------------
#   Multi block leaf
# ----------------------------------------------------------------


class BVTK_NT_MultiBlockLeaf(Node, BVTK_Node):
    """This node breaks down vtkMultiBlock data and outputs one
    user selected block.
    """
    bl_idname = 'BVTK_NT_MultiBlockLeaf'
    bl_label = 'MultiBlockLeaf'

    # Value of enum list in case no blocks
    # are  found in the input data.
    empty_block_list_id = "-1"

    def blocks(self, context):
        """ Returns a list for a dynamic enum. Once verified that
        the input vtk object is decomposable in blocks, the list
        will contain an element for every block, with the following
        information:
        - Block index
        - Block data type (ex. structured grid)
        - Block custom name (if it's defined, in most cases it's not)
        """
        in_node, vtkobj = self.get_input_node("Input")
        if not in_node:
            return [(self.empty_block_list_id, "Input missing", "")]

        elif not vtkobj:
            return [(self.empty_block_list_id, "Input object missing", "")]

        else:
            vtkobj = resolve_algorithm_output(vtkobj)

            if not vtkobj:
                return [(self.empty_block_list_id, "Invalid input", "")]

            if not hasattr(vtkobj, "GetNumberOfBlocks") or not hasattr(vtkobj, "GetBlock"):
                return [(self.empty_block_list_id, "Invalid input object", "")]

            items = []
            meta_flag = True if hasattr(vtkobj, "GetMetaData") else False

            for i in range(vtkobj.GetNumberOfBlocks()):
                block = vtkobj.GetBlock(i)
                meta_data = vtkobj.GetMetaData(i) if meta_flag else None

                if meta_data:
                    custom_name = meta_data.Get(vtk.vtkCompositeDataSet.NAME())
                    if not custom_name:
                        custom_name = ""
                else:
                    custom_name = ""

                name = "[" + str(i) + "]: " + custom_name + " (" + \
                       (block.__class__.__name__ if block else "Empty Block") + ")"
                items.append((str(i), name, ""))

            if not len(items):
                return [(self.empty_block_list_id, "Empty list of blocks", "")]

            return items

    block = bpy.props.EnumProperty(items=blocks, name="Output block")

    def m_properties(self):
        return []

    def m_connections(self):
        return ["Input"], [], [], ["Output"]

    def draw_buttons(self, context, layout):
        in_node, vtkobj = self.get_input_node("Input")
        if not in_node:
            layout.label("Connect a node")
        elif not vtkobj:
            try_update_box(self, layout, "Input has not vtkobj (try updating).")
        else:
            vtkobj = resolve_algorithm_output(vtkobj)

            if not vtkobj:
                return

            class_name = vtkobj.__class__.__name__
            layout.label("Input: "+class_name)

            if not hasattr(vtkobj, "GetNumberOfBlocks") or not hasattr(vtkobj, "GetBlock"):
                question_box(layout, "Input object does not contain\nmultiple blocks of data.")
                return

            layout.prop(self, "block")

    def apply_properties(self, vtkobj):
        pass

    def apply_inputs(self, vtkobj):
        pass

    def get_output(self, socket):
        """Check if the specified block can be retrieved from the input vtk object,
        in case it's possible the said block is returned.
        """
        in_node, vtkobj = self.get_input_node("Input")
        if in_node:
            if vtkobj:
                vtkobj = resolve_algorithm_output(vtkobj)
                if vtkobj:
                    if hasattr(vtkobj, "GetNumberOfBlocks") or not hasattr(vtkobj, "GetBlock"):
                        if self.block != self.empty_block_list_id:
                            return vtkobj.GetBlock(int(self.block))
        return vtkobj


# ----------------------------------------------------------------
#   Texture editor
# ----------------------------------------------------------------


class BVTK_NT_TextureEditor(Node, BVTK_Node):
    """ """
    bl_idname = 'BVTK_NT_TextureEditor'
    bl_label = 'TextureEditor'

    image = bpy.props.PointerProperty(type=bpy.types.Image)
    texture = bpy.props.PointerProperty(type=bpy.types.Texture)

    def m_properties(self):
        return []

    def m_connections(self):
        return ["Input", "Image"], [], [], ["Output"]

    def draw_buttons(self, context, layout):
        layout.template_ID(self, "texture", new="texture.new")

        if not self.texture:
            question_box(layout, "Select a texture")
            return

        if not self.inputs["Image"].links:
            row = aside_label(layout, "Image")
            row.template_ID(self, "image", open="image.open")

    def apply_properties(self, vtk_obj):
        if self.texture:
            if not self.inputs["Image"].links:
                if self.image:
                    self.texture.image = self.image

    def apply_inputs(self, vtkobj):
        if self.texture:
            if self.inputs["Image"].links:
                image = self.get_input_node("Image")[1]

                try:
                    self.texture.image = image
                except TypeError:
                    log.error("Provided input can't be set as the \n"
                              "texture image.")
                except AttributeError:
                    log.error("Texture is not of image texture type.")

    def get_output(self, socket):
        return self.get_input_node("Input")[1]


# ----------------------------------------------------------------
# TimeSelector
# ----------------------------------------------------------------


try:
    # Import, or install if needed, the 'cftime' package
    # needed to convert the time value to a date
    import cftime
except ImportError:
    if pip_installer.pip_install("cftime", ("numpy", "cython")) == 1:
        import cftime


class BVTK_NT_TimeSelector(Node, BVTK_Node):
    """VTK time management node for time variant data. Display time sets,
    time values and set time.
    """
    bl_idname = 'BVTK_NT_TimeSelector'
    bl_label = 'TimeSelector'

    def check_range(self, context):
        time_steps = self.get_time_steps()

        if time_steps:
            size = len(time_steps)

            if self.time_step < 1:
                self.time_step = 1

            elif self.time_step > size:
                self.time_step = size

    def time_arrays(self, context):
        input_obj = self.get_input_obj("Input")

        if not is_netcdf_dataset(input_obj):
            return []

        return [(t, t, t) for t in time_arrays(input_obj)]

    time_array = bpy.props.EnumProperty(name="Time array", items=time_arrays)
    time_step = bpy.props.IntProperty(update=check_range, min=1, default=1)
    date_format = bpy.props.EnumProperty(name="Date format", items=[
        ("%d/%m/%Y %H:%M", "D/M/Y h:m", "D/M/Y h:m"),
        ("%Y/%m/%d %H:%M", "Y/M/D h:m", "Y/M/D h:m"),
        ("%m/%d/%Y %H:%M", "M/D/Y h:m", "M/D/Y h:m"),
        ("%m/%d/%Y %H:%M", "M/D/Y h:m", "M/D/Y h:m"),
        ("%m/%Y", "M/Y", "M/Y"),
        ("%d/%m/%Y", "D/M/Y", "D/M/Y"),
        ("%Y/%m/%d", "Y/M/D", "Y/M/D"),
        ("%m/%d/%Y", "M/D/Y", "M/D/Y"),
        ("%m/%d/%Y", "M/D/Y", "M/D/Y"),
        ("%Y", "Y", "Y")
    ])
    # User defined date time unit and calendar.
    udd_time_unit = bpy.props.EnumProperty(name="Time unit", description="Time unit", items=[
        ("days", "Days", "Days"),
        ("hours", "Hours", "Hours"),
        ("minutes", "Minutes", "Minutes"),
        ("seconds", "Seconds", "Seconds"),
        ("milliseconds", "Milliseconds", "Milliseconds"),
        ("microseconds", "Microseconds", "Microseconds")
    ])
    udd_year = bpy.props.IntProperty(name="First year", description="First year", default=1970)
    udd_month = bpy.props.EnumProperty(name="First month", description="First month", items=[
        ("1", "January", "January"), 
        ("2", "February", "February"), 
        ("3", "March", "March"), 
        ("4", "April", "April"), 
        ("5", "May", "May"), 
        ("6", "June", "June"), 
        ("7", "July", "July"), 
        ("8", "August", "August"), 
        ("9", "September", "September"), 
        ("10", "October", "October"), 
        ("11", "November", "November"), 
        ("12", "December", "December")
    ])
    udd_day = bpy.props.IntProperty(name="First day", description="First day", min=1, max=31, default=1)
    udd_hour = bpy.props.IntProperty(name="Hour", description="Hour", min=0, max=23, default=0)
    udd_min = bpy.props.IntProperty(name="Minute", description="Minute", min=0, max=59, default=0)
    udd_sec = bpy.props.IntProperty(name="Second", description="Second", min=0, max=59, default=0)
    udd_msec = bpy.props.IntProperty(name="Milliseconds", description="Second", min=0, max=999, default=0)
    udd_calendar = bpy.props.EnumProperty(name="Calendar", items=[
        ("standard", "Standard", "Standard"),
        ("gregorian", "Gregorian", "Gregorian"),
        ("proleptic_gregorian", "Prolepticgregorian", "Prolepticgregorian"),
        ("noleap", "Noleap", "Noleap"),
        ("365_day", "365day", "365day"),
        ("360_day", "360day", "360day"),
        ("julian", "Julian", "Julian"),
        ("all_leap", "Allleap", "Allleap"),
        ("366_day", "366day", "366day")
    ])

    def m_properties(self):
        return ["time_step"]

    def m_connections(self):
        return ["Input"], ["Output"], [], ["Time Step", "Date"]

    def setup(self):
        self.outputs.new(BVTK_NS_Date.bl_idname, "")
        self.width = 460

    def get_date(self):
        # Please note: this method is used by the batch scripts,
        # renaming or editing it may compromise them.
        t_val = self.get_time_val()

        if t_val is None:
            return None

        if self.obj_date_is_valid():
            t_units, calendar = self.get_obj_units_calendar()
        else:
            t_units, calendar = self.get_ud_units_calendar()

        try:
            return cftime.num2date(t_val, t_units, calendar)
        except ValueError:
            return None

    def obj_date_is_valid(self, in_obj=None, time_reader=None):
        t_units, calendar = self.get_obj_units_calendar(in_obj, time_reader)

        if not t_units or not calendar:
            return False

        try:
            cftime.num2date(0, t_units, calendar)
            return True
        except ValueError:
            return False

    def get_obj_units_calendar(self, in_obj=None, time_reader=None):
        """Try to retrieve time units and calendar from the input
        object. Method is not fully reliable."""
        if not in_obj:
            in_obj = self.get_input_obj("Input")

        if not in_obj:
            return None, None

        if is_netcdf_dataset(in_obj):
            # NetCDF dataset
            return find_units_calendar(in_obj)

        else:
            # VTK object
            if not time_reader:
                time_reader = self.get_time_reader(self)

            if not time_reader or not has_attributes(time_reader, "GetTimeUnits", "GetCalendar"):
                return None, None

            return time_reader.GetTimeUnits(), time_reader.GetCalendar()

    def get_time_steps(self):
        # Please note: this method is used by the batch scripts,
        # renaming or editing it may compromise them.
        in_node, in_obj = self.get_input_node("Input")

        if is_netcdf_dataset(in_obj):
            # NetCDF4 dataset
            return in_obj.variables[self.time_array]

        if in_node:
            return get_time_steps(in_obj)

        return None

    def get_ud_units_calendar(self):
        """Retrieve time units and calendar defined by the user,
        using this node's properties."""

        units = "{} since {}-{}-{} {}:{}:{}.{}".format(self.udd_time_unit,
                                                       str(self.udd_year).zfill(4),
                                                       self.udd_month.zfill(2),
                                                       str(self.udd_day).zfill(2),
                                                       str(self.udd_hour).zfill(2),
                                                       str(self.udd_min).zfill(2),
                                                       str(self.udd_sec).zfill(2),
                                                       self.udd_msec
                                                       )
        return units, self.udd_calendar

    def get_time_val(self, time_steps=None):
        if not time_steps:
            time_steps = self.get_time_steps()

        if time_steps:
            i = self.time_step - 1

            if -1 < i < len(time_steps):
                return time_steps[i]

        return None

    def draw_date_format(self, layout):
        small_separator(layout)

        self.label_prop(layout, "Calendar", "udd_calendar")
        self.label_prop(layout, "Time units", "udd_time_unit")

        row = aside_label(layout, "Since y/m/d")
        row.prop(self, "udd_year", text="")
        row.prop(self, "udd_month", text="")
        row.prop(self, "udd_day", text="")

        row = aside_label(layout, "h:m:s.ms")

        row.prop(self, "udd_hour", text="h")
        row.prop(self, "udd_min", text="m")
        row.prop(self, "udd_sec", text="s")
        row.prop(self, "udd_msec", text="ms")

        small_separator(layout)

    def draw_buttons(self, context, layout):
        in_node, in_obj = self.get_input_node("Input")

        if not in_node:
            question_box(layout, "Connect a node")

        elif not in_obj:
            try_update_box(self, layout, "Input is null, try updating.")

        else:
            time_steps = self.get_time_steps()

            if not time_steps:
                try_update_box(self, layout, "Input contains a time step array but\n"
                                             "it's invalid or empty. Try updating.")
                return

            t_max = len(time_steps)
            self.label_prop(layout, "Time step (max {})".format(t_max), "time_step")

            if not 0 < self.time_step <= t_max:
                error_box(layout, "Index out of time steps range")
                return

            t_val = self.get_time_val(time_steps)
            label_label(layout, "Time value", t_val)

            if not pip_installer.is_loaded("cftime"):
                error_box(layout, "Module cftime not loaded: install\n"
                                  "it to convert the time value\n"
                                  "into a human readable date.\n"
                                  "> pip install cftime")
                return

            if not self.obj_date_is_valid(in_obj):
                self.draw_date_format(layout)

            if is_netcdf_dataset(in_obj):
                self.label_prop(layout, "Time array", "time_array")

            self.label_prop(layout, "Format", "date_format")
            date = self.get_date()

            if date:
                label_label(layout, "Date", date.strftime(self.date_format))
            else:
                error_box(layout, "Time value could not be converted to a date.")

    def apply_properties(self, vtkobj):
        pass

    def apply_inputs(self, vtkobj):
        pass

    def get_time_reader(self, node):
        """Recursively search the node tree behind the given node for a
        time reader and return it. A node is considerable a time reader
        if its vtk object has 'GetTimeUnits' and 'GetCalendar' methods."""
        if node.get_vtkobj():
            obj = node.get_vtkobj()
            if has_attributes(obj, "GetTimeUnits", "GetCalendar"):
                return obj

        for input in node.inputs:
            for link in input.links:
                in_reader = self.get_time_reader(link.from_node)
                if in_reader:
                    return in_reader

        return None

    def get_formatted_date(self, format_str=None):
        """Convert the given time value in a readable date, if possible."""
        date = self.get_date()

        if date:
            if not format_str:
                format_str = self.date_format
            return "{}".format(date.strftime(format_str))

        return None

    def get_output(self, socket):
        """Time step socket: return the current time step
        Output socket: check if the input is valid and if the time step can be set.
        If tests pass the time step is updated and the input object is returned,
        otherwise None is returned.
        Date socket: check if it's possible to retrieve a readable date and
        return it as a formatted string.
        """
        if socket.name == "Time Step":
            return self.time_step

        in_obj = self.get_input_obj("Input")

        if not in_obj:
            return None

        if socket.name == "Date":
            return self.get_formatted_date()

        if socket.bl_idname == BVTK_NS_Date.bl_idname:
            return self.get_formatted_date(socket.format)

        if is_netcdf_dataset(in_obj):
            # Time selection is managed during
            # conversion. See netcdf_converter.py
            return in_obj

        prod = in_obj.GetProducer()

        if hasattr(prod, "UpdateTimeStep"):
            t_val = self.get_time_val()

            if t_val:
                prod.UpdateTimeStep(t_val)
        else:
            log.warning("ERROR: {} does not have 'UpdateTimeStep' method."
                        .format(prod.__class__.__name__), draw_win=False)

        return resolve_algorithm_output(in_obj)


# ---------------------------------------------------------------------------------
#   Date node socket
# ---------------------------------------------------------------------------------


class BVTK_NS_Date(NodeSocket):
    """BVTK Date Socket"""
    bl_idname = "BVTK_NS_Date"
    bl_label = "BVTK Date Socket"

    format = bpy.props.EnumProperty(items=[
        ("%d", "Day", "Day"),
        ("%m", "Month", "Month"),
        ("%Y", "Year", "Year"),
        ("%H", "Hour", "Hour"),
        ("%M", "Minute", "Minute")
    ])

    def draw(self, context, layout, node, text):
        layout.label(text)
        layout.prop(self, "format", text="")

    def draw_color(self, context, node):
        return 1.0, 0.4, 0.216, 0.5


# ----------------------------------------------------------------


cat = "Instruments"
register.set_category_icon(cat, "GAME")
add_node(BVTK_NT_MultiBlockLeaf, cat)
add_node(BVTK_NT_TimeSelector, cat)
add_node(BVTK_NT_TextureEditor, cat)
register.add_class(BVTK_NS_Date)
