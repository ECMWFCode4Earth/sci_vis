# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   nodes/update.py
#
#   Functions and classes to run the function queue and update
#   the pipeline.
# ---------------------------------------------------------------------------------


import time
from . core import *


# ---------------------------------------------------------------------------------
#   Recursive update
# ---------------------------------------------------------------------------------


def set_color(node, color):
    """Set color of node to color"""
    node.color = color


def update_obj(node, vtkobj):
    """Update node corresponding to vtk obj by applying properties, inputs
    and call to VTK Update()
    """
    #time.sleep(1)
    if hasattr(node, "apply_properties"):
        node.apply_properties(vtkobj)
    if hasattr(node, "apply_inputs"):
        node.apply_inputs(vtkobj)
    if hasattr(vtkobj, "Update"):
        vtkobj.Update()


def set_input_connection(vtkobj, i, input_obj):
    """Set input connection i of vtk obj to input object"""
    #time.sleep(1)
    vtkobj.SetInputConnection(i, input_obj)


def set_input_obj(vtkobj, name, input_obj):
    """Run a named Set function on vtk obj with argument input_obj"""
    #time.sleep(1)
    cmd = 'vtkobj.Set' + name + '( input_obj )'
    exec(cmd, globals(), locals())


def update(node, cb=None, x=True, queue=None):
    """Update the input functions of this node using the function queue.
    Sets color of node to reflect node run status. Finally updates this
    node and queues argument function cb() if argument x is True.
    """
    log.debug('on_update ' + node.name)

    if x:
        path = node_path(node)
        if path in BVTK_FunctionsQueue.queues:
            return
        queue = BVTK_FunctionsQueue(path)
        queue.add(log_check)

    ex_color = node.color.copy()  # Current color
    inputs_color = 0.84, 0.84, 0.73  # Input color
    execute_color = 0.85, 0.6, 0.2  # Execution color

    vtkobj = node.get_vtkobj()

    queue.add(set_color, node, inputs_color)
    for input_node in node.input_nodes():
        update(input_node, None, False, queue)

    queue.add(set_color, node, execute_color)
    queue.add(update_obj, node, vtkobj)
    queue.add(set_color, node, ex_color)

    if x:
        queue.add(set_color, node, execute_color)
        queue.add(log_show)
        if cb:
            queue.add(cb)
        queue.add(set_color, node, ex_color)
        bpy.ops.bvtk.function_queue(node_path=node_path(node))


def no_queue_update(node, cb, x=True):
    """Force the update of all the input connections of this node,
    bypassing the functions queue. Does not update node colors.
    Finally updates this node by calling argument cb() if argument x
    is True, and VTK Update function otherwise.
    """
    if x:
        log.disable_draw_win()
    vtk_obj = node.get_vtkobj()
    for input_node in node.input_nodes():
        no_queue_update(input_node, None, False)
    if x and cb:
        cb()
        log.enable_draw_win()
    else:
        update_obj(node, vtk_obj)


# ---------------------------------------------------------------------------------
#   Function queue
# ---------------------------------------------------------------------------------


class BVTK_FunctionsQueue:
    """Class for Functions Queue. Used for running a queue system for
    BVTK_Nodes functions.
    """
    queues = {}  # node_path -> functions queue

    def __init__(self, node_path):
        self.queues[node_path] = self
        self.node_path = node_path
        self.functions = []
        self.executed = []
        self.i = 0

    def add(self, f, *args):
        self.functions.append((f, (a for a in args)))

    def next_function(self):
        i = self.i
        if i >= len(self.functions):
            self.queues.pop(self.node_path)
            return
        f = self.functions[i]
        if i not in self.executed:
            try:
                f[0](*f[1])
            except Exception as e:
                log.critical("function index: {}, function {}, raised exception: {}".format(i, f[0], e))
                import traceback
                log.debug(traceback.format_exc())
            self.executed.append(i)
            self.i += 1


class BVTK_OT_FunctionQueue(bpy.types.Operator):
    """Operator to call a function in functions queue.
    Calls are spaced (separated in time) by 1/100 s.
    """
    bl_idname = "bvtk.function_queue"
    bl_label = "Run a VTK function in queue"
    node_path = bpy.props.StringProperty()
    _timer = None

    def modal(self, context, event):
        if event.type == 'TIMER':
            if self.node_path in BVTK_FunctionsQueue.queues:
                queue = BVTK_FunctionsQueue.queues[self.node_path]
                queue.next_function()
            else:
                self.cancel(context)
                return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def execute(self, context):
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.01, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)


# ---------------------------------------------------------------------------------
#   Operator Update
# ---------------------------------------------------------------------------------


class BVTK_OT_NodeUpdate(bpy.types.Operator):
    bl_idname = "bvtk.node_update"
    bl_label = "update"
    node_path = bpy.props.StringProperty()
    use_queue = bpy.props.BoolProperty(default=True)

    def execute(self, context):
        check_cache()
        node = eval(self.node_path)
        if node:
            log.info('Updating from {}'.format(node.name))
            cb = None
            if hasattr(node, "update_cb"):
                cb = node.update_cb
            if self.use_queue:
                update(node, cb)
            else:
                no_queue_update(node, cb)
        self.use_queue = True
        return {'FINISHED'}


# ---------------------------------------------------------------------------------
#   Auto Update Scan
# ---------------------------------------------------------------------------------


def map(node, pmap=None):
    """Creates a map which represent
    the status (m_properties and inputs) of
    every node connected to the one given.
    """
    # {} map:        node name -> (nodeprops, nodeinputs)
    # {} nodeprops:  property name -> property value
    # {} nodeinputs: input name -> connected node name

    if not pmap:
        pmap = {}
    props = {}
    for prop in node.m_properties():
        val = getattr(node, prop)
        # Special for arrays. Any other type to include?
        if val.__class__.__name__ == 'bpy_prop_array':
            val = [x for x in val]
        props[prop] = val

    if hasattr(node, 'special_properties'):
        # you can add to a node a function called special_properties
        # to make auto update notice differences outside of m_properties
        props['special_properties'] = node.special_properties()

    links = {}
    for input in node.inputs:
        links[input.name] = ''
        for link in input.links:
            links[input.name] = link.from_node.name
            pmap = map(link.from_node, pmap)
    pmap[node.name] = (props, links)
    return pmap


def differences(map1, map2):
    """Generate differences in properties and inputs of argument maps."""
    props = {}   # differences in properties
    inputs = {}  # differences in inputs
    for node in map1:
        nodeprops1, nodeinputs1 = map1[node]
        if node not in map2:
            props[node] = nodeprops1.keys()
            inputs[node] = nodeinputs1.keys()
        else:
            nodeprops2, nodeinputs2 = map2[node]
            props[node] = compare(nodeprops1, nodeprops2)
            if not props[node]:
                props.pop(node)
            inputs[node] = compare(nodeinputs1, nodeinputs2)
            if not inputs[node]:
                inputs.pop(node)
    return props, inputs


def compare(dict1, dict2):
    """Compare two dictionaries. Return a list of mismatching keys."""
    diff = []
    for k in dict1:
        if k not in dict2:
            diff.append(k)
        else:
            val1 = dict1[k]
            val2 = dict2[k]
            if val1 != val2:
                diff.append(k)
    for k in dict2:
        if k not in dict1:
            diff.append(k)
    return diff


class BVTK_OT_AutoUpdateScan(bpy.types.Operator):
    """BVTK Auto Update Scan"""
    bl_idname = "bvtk.auto_update_scan"
    bl_label = "Auto Update"

    _timer = None
    node_name = bpy.props.StringProperty()
    tree_name = bpy.props.StringProperty()

    def modal(self, context, event):
        if event.type == 'TIMER':
            if self.node_is_valid():
                actual_map = map(self.node)
                props, conn = differences(actual_map, self.last_map)
                if props or conn:
                    self.last_map = actual_map
                    check_cache()
                    try:
                        no_queue_update(self.node, self.node.update_cb)
                    except Exception as e:
                        log.error('ERROR UPDATING ' + str(e))
            else:
                self.cancel(context)
                return {'CANCELLED'}
        return {'PASS_THROUGH'}

    def node_is_valid(self):
        """Node validity test. Return false if node has been deleted or auto
        update has been turned off.
        """
        return self.node.name in self.tree and self.node.auto_update

    def execute(self, context):
        self.tree = bpy.data.node_groups[self.tree_name].nodes
        self.node = bpy.data.node_groups[self.tree_name].nodes[self.node_name]
        self.last_map = map(self.node)
        bpy.ops.bvtk.node_update(node_path=node_path(self.node))
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.01, window=context.window)
        wm.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def cancel(self, context):
        wm = context.window_manager
        wm.event_timer_remove(self._timer)


# ---------------------------------------------------------------------------------
#   Vtk logs
# ---------------------------------------------------------------------------------


out = vtk.vtkFileOutputWindow()
logfile = os.path.join(addon_path, "vtklog.txt")
open(logfile, "w").write("")
out.SetFileName(logfile)
vtk.vtkOutputWindow.SetInstance(out)

last_log = ""  # Current log file contents


def log_check():
    """Saves current log file contents. This function is to be called
    before executing more code that could generate errors, so that
    only latest error messages can be shown to user
    """
    global last_log
    last_log = open(logfile, "r").read()


def log_show():
    """Shows log text of only latest operation"""
    logs = open(logfile, "r").read()
    logs = logs.replace(last_log, "", 1)  # Remove old log text
    if logs:
        def draw(self, context):
            layout = self.layout
            for line in logs.split("\n"):
                if line:
                    row = layout.row()
                    row.label(text=line)

        bpy.context.window_manager.popup_menu(draw, "vtk:", "INFO")


# ---------------------------------------------------------------------------------


register.add_class(BVTK_OT_NodeUpdate)
register.add_class(BVTK_OT_FunctionQueue)
register.add_class(BVTK_OT_AutoUpdateScan)
