# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   utilities/vtk_helper.py
#
#   Define useful functions and classes to manage vtk objects.
# ---------------------------------------------------------------------------------


import vtk


def resolve_algorithm_output(vtkobj):
    """Return vtkobj from vtkAlgorithmOutput"""
    if hasattr(vtkobj, "IsA"):
        if vtkobj.IsA('vtkAlgorithmOutput'):
            vtkobj = vtkobj.GetProducer().GetOutputDataObject(vtkobj.GetIndex())
    return vtkobj


def get_producer(vtk_output_port):
    if vtk_output_port:
        if vtk_output_port.IsA("vtkAlgorithmOutput"):
            return vtk_output_port.GetProducer()
    return None


# ---------------------------------------------------------------------------------
#   Time
# ---------------------------------------------------------------------------------


def get_time_steps(vtk_output_port):
    """Return the list of time steps relative to the given output port."""
    prod = get_producer(vtk_output_port)
    if prod:
        executive = prod.GetExecutive()
        out_info = prod.GetOutputInformation(vtk_output_port.GetIndex())
        if hasattr(executive, "TIME_STEPS"):
            return out_info.Get(executive.TIME_STEPS())
    return None


def set_time_step(vtk_output_port, time_value):
    """Set the given time step, update the vtk object and return the output."""
    prod = get_producer(vtk_output_port)

    if hasattr(prod, "UpdateTimeStep"):
        prod.UpdateTimeStep(time_value)
        return prod.GetOutput(vtk_output_port.GetIndex())

    return None


def _complete_time_range(vtk_output_port, array):
    if not vtk_output_port:
        return

    time_steps = get_time_steps(vtk_output_port)
    g_range = {}

    for t_val in time_steps:
        vtk_obj = set_time_step(vtk_output_port, t_val)
        data = {}

        if hasattr(vtk_obj, "GetPointData"):
            data["Point data"] = vtk_obj.GetPointData()

        if hasattr(vtk_obj, "GetCellData"):
            data["Cell data"] = vtk_obj.GetCellData()

        if hasattr(vtk_obj, "GetFieldData"):
            data["Field data"] = vtk_obj.GetFieldData()

        for k in data:
            d = data[k]
            arrays = g_range.setdefault(k, {})

            for i in range(d.GetNumberOfArrays()):
                arr = d.GetArray(i)
                arr_r = arr.GetRange()
                name = arr.GetName()
                print(arr_r[0], arr_r[1], name)
                glob_r = arrays.setdefault(name, [None, None])

                if glob_r[0] is None or glob_r[0] > arr_r[0]:
                    glob_r[0] = arr_r[0]

                if glob_r[1] is None or glob_r[1] < arr_r[1]:
                    glob_r[1] = arr_r[1]

    return g_range


def complete_time_range(vtk_output_port, attribute_type, array_index):
    """Compute the complete range for all the time steps for the
    specified array. The attribute type may be:
    POINT - point data - Defined in vtkDataSet subclasses.
    CELL - cell data - Defined in vtkDataSet subclasses.
    FIELD - field data - Defined in vtkDataSet subclasses.
    VERTEX - vertex data - Defined in vtkGraph subclasses.
    EDGE - edge data - Defined in vtkGraph subclasses.
    ROW - row data - Defined in vtkTable.
    """

    if not vtk_output_port:
        return

    time_steps = get_time_steps(vtk_output_port)
    r_min, r_max = None, None

    for t_val in time_steps:
        vtk_obj = set_time_step(vtk_output_port, t_val)

        attribute_arrays = vtk_obj.GetAttributesAsFieldData(attribute_type)

        if not attribute_arrays:
            return

        arr = attribute_arrays.GetArray(array_index)
        arr_r = arr.GetRange()

        if r_min is None or r_min > arr_r[0]:
            r_min = arr_r[0]

        if r_max is None or r_max < arr_r[1]:
            r_max = arr_r[1]

    return r_min, r_max
