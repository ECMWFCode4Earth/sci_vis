# <pep8 compliant>
# ---------------------------------------------------------------------------------
#   layout/__init__.py
#
#   Define the required modules to import.
# ---------------------------------------------------------------------------------

_modules = [
    "examples",
    "favorites",
    "inspect_panel",
    "showhide_properties",
]
